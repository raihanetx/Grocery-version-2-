'use client'

import React, { useState, useEffect, useRef } from 'react'

// Types
interface CartItem {
  id: number
  name: string
  price: number
  oldPrice: number
  img: string
  weight: string
}

interface Review {
  id: number
  initials: string
  name: string
  rating: number
  text: string
  date: string
}

interface Category {
  id: string
  name: string
  type: string
  icon: string
  image: string
  items: number
  created: string
  status: string
}

interface Product {
  id: number
  name: string
  category: string
  image: string
  variants: string
  price: string
  discount: string
  offer: boolean
  status: string
  shortDesc?: string
  longDesc?: string
  offerSwitch?: boolean
}

interface InventoryItem {
  id: number
  name: string
  category: string
  image: string
  variants: { name: string; stock: number; initialStock: number }[]
  lastEdited: string
}

interface Alert {
  title: string
  desc: string
  type: string
}

interface AdminReview {
  id: number
  product: string
  productCategory: string
  productImg: string
  customerName: string
  rating: number
  text: string
  date: string
  time: string
}

interface OrderItem {
  name: string
  variant: string | null
  qty: number
  basePrice: number
  offerText: string | null
  offerDiscount: number
  couponCode: string | null
  couponDiscount: number
}

interface Order {
  id: string
  customer: string
  phone: string
  address: string
  date: string
  time: string
  paymentMethod: string
  status: 'pending' | 'approved' | 'canceled'
  courierStatus: string
  subtotal: number
  delivery: number
  discount: number
  couponCodes: string[]
  couponAmount: number
  total: number
  canceledBy: string | null
  items: OrderItem[]
}

interface Coupon {
  id: string
  code: string
  type: 'pct' | 'fixed'
  value: number
  scope: 'all' | 'products' | 'categories'
  expiry: string
  selectedProducts?: number[]
  selectedCategories?: string[]
}

interface CouponProduct {
  id: number
  name: string
  price: string
  img: string
}

interface CouponCategory {
  name: string
  color: string
}

interface AbandonedVariant {
  label: string | null
  qty: number
}

interface AbandonedProduct {
  name: string
  variants: AbandonedVariant[]
}

interface AbandonedHistory {
  date: string
  time: string
  timeAgo: string
  status: 'abandoned' | 'completed'
  products: AbandonedProduct[]
  total: number
}

interface AbandonedCheckout {
  id: number
  name: string
  phone: string
  address: string
  visitTime: string
  visitDate: string
  totalVisits: number
  completedOrders: number
  history: AbandonedHistory[]
}

interface CustomerOrder {
  date: string
  time: string
  timeAgo: string
  visitCount: number
  products: AbandonedProduct[]
  total: number
}

interface CustomerProfile {
  id: number
  name: string
  phone: string
  address: string
  totalSpent: number
  totalOrders: number
  orders: CustomerOrder[]
}

interface Settings {
  websiteName: string
  slogan: string
  faviconUrl: string
  insideDhakaDelivery: number
  outsideDhakaDelivery: number
  freeDeliveryMin: number
  whatsappNumber: string
  phoneNumber: string
  facebookUrl: string
  messengerUsername: string
  aboutUs: string
  termsConditions: string
  refundPolicy: string
  privacyPolicy: string
}

interface Credentials {
  username: string
  currentPassword: string
  newPassword: string
  confirmPassword: string
  apiKey: string
  secretKey: string
  webhookUrl: string
}

// 1. HEADER
const Header = ({ view, setView, cartCount }: { view: string; setView: (v: string) => void; cartCount: number }) => (
  <header className="w-full bg-white border-b border-gray-200 shadow-[0_1px_4px_rgba(0,0,0,0.08)] flex items-center justify-between px-3 md:px-[2rem] h-[70px] md:h-[100px] sticky top-0 z-[200]">
    <div className="flex items-center shrink-0 w-auto">
      {(view === 'product' || view === 'admin') && (
        <div className="mr-2 cursor-pointer hover:text-orange-500 transition-colors" onClick={() => setView('shop')}>
          <i className="ri-arrow-left-line text-2xl md:text-3xl text-gray-700"></i>
        </div>
      )}
      <div className="flex items-center gap-2 cursor-pointer" onClick={() => setView('shop')}>
        <img src="https://i.postimg.cc/4xZk3k2j/IMG-20260226-120143.png" alt="Logo" className="h-[70px] w-[70px] md:h-[90px] md:w-[90px] object-contain" />
      </div>
    </div>

    <form className="hidden md:flex flex-1 justify-center mx-[1rem] max-w-2xl">
      <div className="flex items-center border border-gray-300 rounded-full px-6 w-full bg-transparent h-12 relative transition-all duration-200 focus-within:border-orange-500">
        <input type="text" name="search" placeholder="Search Product" className="w-full outline-none bg-transparent text-lg text-gray-700 placeholder-gray-400 pr-10" />
        <button type="button" className="absolute right-5 cursor-pointer hover:text-black transition-colors">
          <i className="ri-search-line text-gray-400 text-2xl"></i>
        </button>
      </div>
    </form>

    <form className="md:hidden flex items-center border border-gray-300 rounded-full px-3 bg-white h-[36px] flex-1 mr-4 ml-2 relative">
      <input type="text" name="search" placeholder="Search..." className="w-full outline-none bg-transparent text-sm text-gray-700 placeholder-gray-400 pr-6 pb-[1px]" />
      <button type="button" className="absolute right-2">
        <i className="ri-search-line text-gray-400 text-base"></i>
      </button>
    </form>

    <div className="hidden md:flex items-center justify-end h-10 shrink-0 gap-0">
      <div className="px-5 border-r border-gray-200 cursor-pointer hover:text-orange-500 relative transition-colors h-full flex items-center" onClick={() => setView('cart')}>
        <div className="relative">
          <i className="ri-shopping-bag-line text-[28px] text-gray-600 leading-none"></i>
          {cartCount > 0 && <span className="absolute -top-1 -right-1 h-4 w-4 bg-red-500 rounded-full text-[9px] text-white flex items-center justify-center font-bold border-2 border-white">{cartCount}</span>}
        </div>
      </div>
      <div className="px-5 border-r border-gray-200 cursor-pointer hover:text-orange-500 transition-colors h-full flex items-center" onClick={() => setView('orders')}>
        <i className="ri-file-list-3-line text-[28px] text-gray-600 leading-none"></i>
      </div>
      <div className="px-5 border-r border-gray-200 cursor-pointer hover:text-orange-500 transition-colors h-full flex items-center">
        <i className="ri-user-line text-[28px] text-gray-600 leading-none"></i>
      </div>
      <div className="pl-5 cursor-pointer hover:text-orange-500 transition-colors h-full flex items-center" onClick={() => setView('admin')}>
        <i className="ri-dashboard-line text-[28px] text-gray-600 leading-none"></i>
      </div>
    </div>

    <div className="md:hidden flex items-center justify-end h-10 shrink-0 gap-3">
      <div className="cursor-pointer hover:text-orange-500 relative transition-colors" onClick={() => setView('cart')}>
        <i className="ri-shopping-bag-line text-[24px] text-gray-600 leading-none"></i>
        {cartCount > 0 && <span className="absolute -top-1 -right-1 h-3.5 w-3.5 bg-red-500 rounded-full text-[9px] text-white flex items-center justify-center font-bold border-2 border-white">{cartCount}</span>}
      </div>
      <div className="cursor-pointer hover:text-orange-500 transition-colors" onClick={() => setView('admin')}>
        <i className="ri-dashboard-line text-[24px] text-gray-600 leading-none"></i>
      </div>
    </div>
  </header>
)

// 2. BOTTOM NAV
const BottomNav = ({ view, setView }: { view: string; setView: (v: string) => void }) => (
  <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-[0_-1px_4px_rgba(0,0,0,0.08)] h-[60px] flex justify-around items-center md:hidden z-[200]">
    <div onClick={() => setView('shop')} className={`flex flex-col items-center justify-center flex-1 h-full cursor-pointer transition-colors ${view==='shop'?'text-orange-500':'text-gray-500'}`}>
      <i className="ri-home-4-line text-[22px] mb-[1px] leading-none"></i>
      <span className="text-[10px] font-medium leading-none mt-1">Home</span>
    </div>
    <div onClick={() => setView('shop')} className="flex flex-col items-center justify-center flex-1 h-full cursor-pointer text-gray-500 hover:text-orange-500 transition-colors">
      <i className="ri-store-line text-[22px] mb-[1px] leading-none"></i>
      <span className="text-[10px] font-medium leading-none mt-1">Shop</span>
    </div>
    <div onClick={() => setView('orders')} className={`flex flex-col items-center justify-center flex-1 h-full cursor-pointer transition-colors ${view==='orders'?'text-orange-500':'text-gray-500'}`}>
      <i className="ri-todo-line text-[22px] mb-[1px] leading-none"></i>
      <span className="text-[10px] font-medium leading-none mt-1">Orders</span>
    </div>
  </div>
)

// 3. SHOP COMPONENT
const Shop = ({ setView, addToCart }: { setView: (v: string) => void; addToCart: (item: CartItem) => void }) => {
  const products: CartItem[] = [
    { id: 1, name: 'Fresh Organic Carrots', price: 80, oldPrice: 95, img: 'https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png', weight: '1 KG' },
    { id: 2, name: 'Premium Potatoes', price: 45, oldPrice: 55, img: 'https://i.postimg.cc/d1vdTWyL/1000020583-removebg-preview.png', weight: '1 KG' },
    { id: 3, name: 'Fresh Tomatoes', price: 60, oldPrice: 75, img: 'https://i.postimg.cc/mr7CkxtQ/1000020584-removebg-preview.png', weight: '500g' },
    { id: 4, name: 'Organic Spinach', price: 30, oldPrice: 40, img: 'https://i.postimg.cc/MG1VHkvz/1000020586-removebg-preview.png', weight: '1 Bundle' },
    { id: 5, name: 'Crisp Cucumbers', price: 50, oldPrice: 65, img: 'https://i.postimg.cc/TPng18pY/1000020587-removebg-preview.png', weight: '1 KG' },
    { id: 6, name: 'Fresh Onions', price: 35, oldPrice: 45, img: 'https://i.postimg.cc/1zDwXxfR/1000020590-removebg-preview.png', weight: '1 KG' },
    { id: 7, name: 'Green Peppers', price: 55, oldPrice: 70, img: 'https://i.postimg.cc/TPng18pL/1000020591-removebg-preview.png', weight: '500g' },
    { id: 8, name: 'Fresh Garlic', price: 40, oldPrice: 50, img: 'https://i.postimg.cc/mr7Ckxt4/1000020592-removebg-preview.png', weight: '250g' },
    { id: 9, name: 'Organic Ginger', price: 45, oldPrice: 55, img: 'https://i.postimg.cc/K86tmcvZ/1000020593-removebg-preview.png', weight: '200g' },
    { id: 10, name: 'Fresh Broccoli', price: 70, oldPrice: 85, img: 'https://i.postimg.cc/qR0nCm36/1000020611-removebg-preview.png', weight: '1 Piece' },
    { id: 11, name: 'Red Apples', price: 90, oldPrice: 110, img: 'https://i.postimg.cc/x1wL9jTV/IMG-20260228-163137.png', weight: '1 KG' },
    { id: 12, name: 'Fresh Bananas', price: 50, oldPrice: 60, img: 'https://i.postimg.cc/bw71qYYK/IMG-20260228-163147.png', weight: '1 Dozen' },
    { id: 13, name: 'Sweet Oranges', price: 80, oldPrice: 95, img: 'https://i.postimg.cc/mr7Ckxtx/IMG-20260228-163156.png', weight: '1 KG' },
    { id: 14, name: 'Grapes Green', price: 120, oldPrice: 140, img: 'https://i.postimg.cc/htkVK4PD/IMG-20260228-163208.png', weight: '500g' },
    { id: 15, name: 'Mango Fresh', price: 150, oldPrice: 180, img: 'https://i.postimg.cc/Z5G6JYKm/IMG-20260228-163217.png', weight: '1 KG' },
    { id: 16, name: 'Papaya Ripe', price: 60, oldPrice: 75, img: 'https://i.postimg.cc/vZJ5G8Hd/IMG-20260228-163228.png', weight: '1 Piece' }
  ]

  const heroImages = [
    'https://i.postimg.cc/zfN3dyGV/Whisk-785426d5b3a55ac9f384abb1c653efdedr.jpg',
    'https://i.postimg.cc/QCFMB50H/Whisk-186f0227f2203638e6f4806f9343b15cdr.jpg',
    'https://i.postimg.cc/0jzN6mcM/Whisk-21cf4f35609655e91844ef8ae3c7f4c9dr.jpg',
    'https://i.postimg.cc/8c7CFWtv/Whisk-2215d2b37231bb1a2ec403753c88d38fdr.jpg',
    'https://i.postimg.cc/mkPrcM83/Whisk-6915ce64bba40ba9e924b2c9991fd1f7dr.jpg',
    'https://i.postimg.cc/x8XdkHtL/Whisk-7725ed9fada3d57b47746dad0037a667dr.jpg',
    'https://i.postimg.cc/j2DjWNZX/Whisk-92ca7933c1a594782e4409c2912ffaebdr.jpg',
    'https://i.postimg.cc/mkPrcM8P/Whisk-fca8a55bd19b6f9a49c4cafbfd6d5bd5dr.jpg',
  ]
  const [currentHero, setCurrentHero] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentHero((prev) => (prev + 1) % heroImages.length)
    }, 4000)
    return () => clearInterval(interval)
  }, [])

  return (
    <main className="flex-grow">
      {/* Hero Carousel */}
      <section className="w-full pb-4 md:pb-0">
        <div className="mx-6 mt-6 md:mx-6 md:mt-6 relative h-[172.5px] md:h-[260px] rounded-2xl overflow-hidden shadow-xl group">
          {heroImages.map((img, i) => (
            <div
              key={i}
              className={`absolute inset-0 bg-cover bg-center transition-opacity duration-700 ${i === currentHero ? 'opacity-100' : 'opacity-0'}`}
              style={{backgroundImage: `url('${img}')`}}
            ></div>
          ))}
          <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent"></div>
          {/* Carousel Indicators */}
          <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 flex gap-2">
            {heroImages.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentHero(i)}
                className={`w-2 h-2 rounded-full transition-all ${i === currentHero ? 'bg-white w-4' : 'bg-white/50'}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="pt-2 pb-6 md:pt-10 md:pb-8">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-4 md:mb-8">
            <h2 className="text-xl md:text-3xl font-bold text-gray-900 font-bangla">ক্যাটাগরি</h2>
            <p className="text-gray-500 mt-1 text-sm md:text-base font-bangla">আপনার প্রয়োজনীয় সবকিছু এখানেই পাবেন</p>
          </div>
          <div className="flex justify-center">
            <div className="flex gap-4 md:gap-5 overflow-x-auto md:flex-wrap md:justify-center pb-2 md:pb-0 -mx-4 px-4 md:mx-0 md:px-0 no-scrollbar">
              {[
                { icon: 'ri-plant-line', name: 'Vegetables', count: 48 },
                { icon: 'ri-apple-line', name: 'Fruits', count: 32 },
                { icon: 'ri-drop-line', name: 'Dairy', count: 24 },
                { icon: 'ri-cup-line', name: 'Beverages', count: 18 },
                { icon: 'ri-restaurant-line', name: 'Meat', count: 15 },
                { icon: 'ri-cookie-line', name: 'Snacks', count: 28 },
              ].map((cat, i) => (
                <div key={i} className="flex-shrink-0 flex flex-col items-center group cursor-pointer">
                  <div className="w-[60px] h-[60px] md:w-[80px] md:h-[80px] rounded-xl border border-gray-300 bg-white flex items-center justify-center text-gray-700 group-hover:text-[#16a34a] group-hover:border-[#16a34a] transition-colors duration-300 mb-1">
                    <i className={`${cat.icon} text-2xl md:text-4xl`}></i>
                  </div>
                  <span className="text-xs font-medium text-gray-700">{cat.name}</span>
                  <span className="text-[10px] text-gray-400">{cat.count} items</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* OFFER CARDS SECTION */}
      <section id="offers" className="pb-6 md:pb-10">
        <div className="container mx-auto px-4 md:px-6">
          <div className="mb-4 text-left">
            <h2 className="text-lg md:text-2xl font-bold text-gray-900">Offer Cards</h2>
            <p className="text-gray-500 mt-0.5 text-xs md:text-sm">Exclusive deals just for you</p>
          </div>
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2 -mx-4 px-4 md:mx-0 md:px-0">
            <div className="bg-white rounded-[10px] flex items-center overflow-hidden border border-[#eee] transition-all shrink-0 w-[240px] h-[100px] cursor-pointer" onClick={() => setView('product')}>
              <div className="w-[80px] h-full flex justify-center items-center p-2 pl-6">
                <img src="https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png" alt="Product" className="max-w-full max-h-full object-contain" />
              </div>
              <div className="w-[1px] h-[70%] bg-[#e0e0e0]"></div>
              <div className="flex-1 py-2 px-3 flex flex-col justify-center">
                <div className="text-[11px] text-[#ff4757] font-bold mb-1">Save 16% today</div>
                <h2 className="text-[13px] font-semibold text-[#333] mb-1 truncate">Fresh Carrots</h2>
                <div className="flex items-center gap-2">
                  <span className="text-[14px] font-bold text-[#16a34a]">TK80.00</span>
                  <span className="text-[10px] line-through text-[#aaa]">TK95.00</span>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-[10px] flex items-center overflow-hidden border border-[#eee] transition-all shrink-0 w-[240px] h-[100px] cursor-pointer" onClick={() => setView('product')}>
              <div className="w-[80px] h-full flex justify-center items-center p-2 pl-6">
                <img src="https://i.postimg.cc/d1vdTWyL/1000020583-removebg-preview.png" alt="Product" className="max-w-full max-h-full object-contain" />
              </div>
              <div className="w-[1px] h-[70%] bg-[#e0e0e0]"></div>
              <div className="flex-1 py-2 px-3 flex flex-col justify-center">
                <div className="text-[11px] text-[#ff4757] font-bold mb-1">Flash Deal: 18%</div>
                <h2 className="text-[13px] font-semibold text-[#333] mb-1 truncate">Premium Potatoes</h2>
                <div className="flex items-center gap-2">
                  <span className="text-[14px] font-bold text-[#16a34a]">TK45.00</span>
                  <span className="text-[10px] line-through text-[#aaa]">TK55.00</span>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-[10px] flex items-center overflow-hidden border border-[#eee] transition-all shrink-0 w-[240px] h-[100px] cursor-pointer" onClick={() => setView('product')}>
              <div className="w-[80px] h-full flex justify-center items-center p-2 pl-6">
                <img src="https://i.postimg.cc/x1wL9jTV/IMG-20260228-163137.png" alt="Product" className="max-w-full max-h-full object-contain" />
              </div>
              <div className="w-[1px] h-[70%] bg-[#e0e0e0]"></div>
              <div className="flex-1 py-2 px-3 flex flex-col justify-center">
                <div className="text-[11px] text-[#ff4757] font-bold mb-1">Limited Stock</div>
                <h2 className="text-[13px] font-semibold text-[#333] mb-1 truncate">Red Apples</h2>
                <div className="flex items-center gap-2">
                  <span className="text-[14px] font-bold text-[#16a34a]">TK90.00</span>
                  <span className="text-[10px] line-through text-[#aaa]">TK110.00</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Product Grid */}
      <section className="pb-12 pt-2">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
            {products.map((item) => (
              <div key={item.id} onClick={() => setView('product')} className="bg-white p-3 shadow-sm relative cursor-pointer transition-all duration-300 flex flex-col w-full min-h-[250px] border border-gray-200 rounded-2xl hover:shadow-lg">
                <span className="absolute top-2 left-2 bg-red-600 text-white text-[10px] font-bold px-2 py-1 rounded z-10">-15%</span>
                <div className="flex-grow flex items-center justify-center py-2">
                  <div className="w-full h-[140px] flex items-center justify-center">
                    <img src={item.img} alt={item.name} className="w-full h-full object-contain" loading="lazy"/>
                  </div>
                </div>
                <div className="flex flex-col mt-auto">
                  <h3 className="text-sm font-medium text-gray-900 truncate font-bangla">{item.name}</h3>
                  <div className="flex items-center gap-2 mb-2 mt-0.5">
                    <span className="text-sm font-semibold text-[#16a34a]">TK {item.price}</span>
                    <span className="text-xs text-gray-500 line-through">TK {item.oldPrice}</span>
                  </div>
                  <button className="w-full text-xs font-bold py-1.5 flex items-center justify-center gap-1 bg-[#16a34a] text-white rounded-full border-none cursor-pointer transition-transform duration-200 active:scale-95" 
                    onClick={(e) => { 
                      e.stopPropagation(); 
                      addToCart(item);
                    }}>
                    <i className="ri-shopping-cart-line text-sm"></i>
                    Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  )
}

// 4. PRODUCT DETAIL
const ProductDetail = ({ setView, addToCart }: { setView: (v: string) => void; addToCart: (item: CartItem) => void }) => {
  const [activeTab, setActiveTab] = useState('desc')
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [userRating, setUserRating] = useState(0)
  const [reviews, setReviews] = useState<Review[]>([
    { id: 1, initials: 'JP', name: 'Joya P.', rating: 5, text: 'Super fresh! My kids loved them.', date: '2 Oct 2023' },
    { id: 2, initials: 'AR', name: 'Ahmed R.', rating: 4, text: 'Good quality but delivery took time.', date: '5 Oct 2023' }
  ])
  
  const imgRef = useRef<HTMLDivElement>(null)
  const detRef = useRef<HTMLDivElement>(null)
  const tabRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    window.scrollTo(0,0)
  }, [])

  const handleSubmitReview = () => {
    const nameInput = document.getElementById('reviewName') as HTMLInputElement
    const textInput = document.getElementById('reviewText') as HTMLTextAreaElement
    const name = nameInput?.value || ''
    const text = textInput?.value || ''
    
    if(name && text && userRating > 0) {
      const initials = name.match(/(\b\S)?/g)?.join("").match(/(^\S|\S$)?/g)?.join("").toUpperCase() || name.substring(0, 2).toUpperCase()
      const newReview: Review = { id: Date.now(), initials, name, rating: userRating, text, date: 'Just now' }
      setReviews([newReview, ...reviews])
      setIsModalOpen(false)
      setUserRating(0)
    } else {
      alert("Please fill all fields and rate.")
    }
  }

  const sampleProduct: CartItem = { id: 99, name: 'Organic Premium Carrots', price: 80, oldPrice: 95, img: 'https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png', weight: '1 KG' }

  return (
    <div className="bg-white w-full py-6 md:py-10 px-[30px] md:px-[45px] max-w-5xl mx-auto min-h-[calc(100vh-120px)]">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-10">
        <div className="flex flex-col w-full">
          <div ref={imgRef} className="flex-grow relative w-full bg-gray-50 rounded-2xl overflow-hidden border border-gray-100 shadow-sm min-h-[200px]">
            <div className="absolute top-3 left-3 bg-[#16a34a] text-white text-[10px] font-bold px-2.5 py-1 rounded-md z-10 shadow-md">-15% OFF</div>
            <img src={sampleProduct.img} className="absolute inset-0 w-full h-full object-contain" alt="Carrots" />
          </div>
          <div className="grid grid-cols-4 gap-2 mt-3 flex-shrink-0">
            {[1,2,3,4].map(i => (
              <div key={i} className="aspect-square bg-gray-50 rounded-lg overflow-hidden border border-gray-100 cursor-pointer hover:opacity-80 transition-opacity">
                <img src={sampleProduct.img} className="w-full h-full object-cover" alt="Product thumbnail" />
              </div>
            ))}
          </div>
        </div>
        <div ref={detRef} className="flex flex-col">
          <h1 className="text-xl md:text-3xl font-bold text-[#1F2937] leading-tight mb-3">{sampleProduct.name}</h1>
          <div className="flex items-center flex-wrap gap-4 mb-5"> 
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-bold text-[#16a34a]">TK<span>{sampleProduct.price}</span></span>
              <span className="text-sm text-gray-300 line-through font-medium">TK{sampleProduct.oldPrice}</span>
            </div>
            <div className="w-px h-4 bg-gray-200"></div>
            <span className="text-sm font-semibold text-[#1F2937]">(500g)</span>
          </div>
          <p className="text-sm text-[#6B7280] leading-relaxed mb-6 line-clamp-2">Farm-fresh organic carrots handpicked from local farms. Crisp, sweet, and perfect for salads, juices, or cooking. Rich in beta-carotene and essential vitamins.</p>
          
          {/* Quantity & Variant Section */}
          <div style={{background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '12px', padding: '16px', marginBottom: '16px'}}>
            <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
              <div>
                <span style={{fontSize: '11px', fontWeight: 600, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px'}}>Quantity</span>
                <div style={{display: 'flex', alignItems: 'center', gap: '12px', marginTop: '8px'}}>
                  <button style={{width: '32px', height: '32px', borderRadius: '8px', border: '1px solid #e2e8f0', background: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#64748b'}}><i className="ri-subtract-line"></i></button>
                  <span style={{fontSize: '16px', fontWeight: 700, color: '#0f172a', minWidth: '24px', textAlign: 'center'}}>1</span>
                  <button style={{width: '32px', height: '32px', borderRadius: '8px', border: '1px solid #e2e8f0', background: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#64748b'}}><i className="ri-add-line"></i></button>
                </div>
              </div>
              <div style={{textAlign: 'right'}}>
                <span style={{fontSize: '11px', fontWeight: 600, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px'}}>Variant</span>
                <div style={{display: 'flex', gap: '8px', marginTop: '8px'}}>
                  <button style={{padding: '6px 14px', borderRadius: '8px', border: '1px solid #16a34a', background: 'white', color: '#16a34a', fontSize: '12px', fontWeight: 600, cursor: 'pointer'}}>500g</button>
                  <button style={{padding: '6px 14px', borderRadius: '8px', border: '1px solid #e2e8f0', background: 'white', color: '#64748b', fontSize: '12px', fontWeight: 500, cursor: 'pointer'}}>1 KG</button>
                </div>
              </div>
            </div>
            <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '16px', paddingTop: '12px', borderTop: '1px solid #e2e8f0'}}>
              <span style={{fontSize: '13px', color: '#64748b'}}>Total</span>
              <span style={{fontSize: '18px', fontWeight: 700, color: '#0f172a'}}>TK80</span>
            </div>
          </div>

          <div className="flex gap-3 mt-auto">
            <button onClick={() => addToCart(sampleProduct)} className="btn-tap flex-1 border border-[#16a34a] text-[#16a34a] h-12 rounded-lg text-sm font-bold hover:bg-teal-50 uppercase flex items-center justify-center gap-2"><i className="ri-shopping-cart-line"></i> Add to Cart</button>
            <button onClick={() => setView('checkout')} className="btn-tap flex-1 bg-[#16a34a] text-white h-12 rounded-lg text-sm font-bold shadow-lg shadow-teal-100 uppercase flex items-center justify-center gap-2"><i className="ri-shopping-bag-line"></i> Buy Now</button>
          </div>
        </div>
      </div>
      
      <div ref={tabRef} className="mt-12">
        <div className="flex justify-center items-center gap-5 border-y border-gray-200 py-2.5 mb-8 overflow-x-auto no-scrollbar whitespace-nowrap px-4 md:px-0">
          <button onClick={() => setActiveTab('desc')} className={`text-sm transition-colors ${activeTab === 'desc' ? 'text-[#1F2937] font-bold' : 'text-gray-400 font-medium'}`}>Description</button>
          <div className="w-px h-3 bg-gray-300 shrink-0"></div>
          <button onClick={() => setActiveTab('rev')} className={`text-sm transition-colors ${activeTab === 'rev' ? 'text-[#1F2937] font-bold' : 'text-gray-400 font-medium'}`}>Reviews</button>
          <div className="w-px h-3 bg-gray-300 shrink-0"></div>
          <button onClick={() => setActiveTab('qa')} className={`text-sm transition-colors ${activeTab === 'qa' ? 'text-[#1F2937] font-bold' : 'text-gray-400 font-medium'}`}>FAQ</button>
        </div>
        <div className="max-w-2xl mx-auto">
          {activeTab === 'desc' && (
            <div className="fade-in text-[0.9rem] text-[#6B7280] leading-7 text-center md:text-left">
              <p className="mb-4">These premium organic carrots are sourced directly from trusted local farms in Bangladesh. Known for their vibrant orange color, natural sweetness, and satisfying crunch, they are perfect for a variety of culinary uses - from fresh salads and healthy juices to hearty curries and stir-fries.</p>
              <p className="mb-4">Our carrots are harvested at peak maturity to ensure maximum flavor and nutritional value. They are carefully cleaned and packed to maintain freshness during delivery.</p>
              <ul className="inline-block text-left text-xs space-y-2 mt-4">
                <li className="flex items-center gap-2"><i className="ri-check-line text-[#16a34a]"></i> 100% Organic & Pesticide-Free</li>
                <li className="flex items-center gap-2"><i className="ri-check-line text-[#16a34a]"></i> Rich in Beta-Carotene & Vitamin A</li>
                <li className="flex items-center gap-2"><i className="ri-check-line text-[#16a34a]"></i> Sourced from Local BD Farms</li>
                <li className="flex items-center gap-2"><i className="ri-check-line text-[#16a34a]"></i> Delivered Fresh Within 24 Hours</li>
              </ul>
            </div>
          )}
          {activeTab === 'rev' && (
            <div className="fade-in">
              <div className="flex justify-center md:justify-start mb-6 cursor-pointer text-[#16a34a]" onClick={() => setIsModalOpen(true)}>
                <div className="flex items-center gap-2"><i className="ri-edit-circle-line text-lg"></i><span className="text-sm font-semibold underline decoration-dotted">Write a review</span></div>
              </div>
              <div className="flex flex-col gap-4">
                {reviews.map((rev) => (
                  <div key={rev.id} className="p-4 rounded-lg bg-gray-50 border border-gray-100 fade-in w-full">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-white border border-gray-200 text-[#16a34a] flex items-center justify-center text-xs font-bold">{rev.initials}</div>
                        <span className="text-sm font-bold text-[#1F2937]">{rev.name}</span>
                        <div className="flex text-yellow-400 text-[10px] ml-1">
                          {[1,2,3,4,5].map(i => <i key={i} className={`${i <= rev.rating ? 'ri-star-fill' : 'ri-star-line'}`}></i>)}
                        </div>
                      </div>
                      <span className="text-[10px] text-gray-400 font-medium">{rev.date}</span>
                    </div>
                    <div className="pl-[44px]">
                      <p className="text-xs text-[#6B7280] leading-relaxed">{rev.text}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {activeTab === 'qa' && (
            <div className="fade-in">
              <div className="space-y-4">
                <div className="border border-gray-100 rounded-lg p-4 bg-gray-50">
                  <h4 className="text-sm font-bold text-[#1F2937] mb-1 flex items-center gap-2"><i className="ri-question-fill text-[#16a34a]"></i> Is this item fresh?</h4>
                  <p className="text-xs text-[#6B7280] pl-6">Yes, we harvest daily from local organic farms to ensure maximum freshness upon delivery.</p>
                </div>
                <div className="border border-gray-100 rounded-lg p-4 bg-gray-50">
                  <h4 className="text-sm font-bold text-[#1F2937] mb-1 flex items-center gap-2"><i className="ri-question-fill text-[#16a34a]"></i> What is the shelf life?</h4>
                  <p className="text-xs text-[#6B7280] pl-6">Typically lasts 7-10 days if refrigerated properly in a crisper drawer.</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* You May Like Section */}
      <div style={{marginTop: '48px'}}>
        <div className="flex items-center justify-between mb-6">
          <h2 style={{fontSize: '20px', fontWeight: 700, color: '#0f172a'}}>You May Like</h2>
          <button className="text-sm font-medium text-[#16a34a] hover:underline flex items-center gap-1">
            View All <i className="ri-arrow-right-line"></i>
          </button>
        </div>
        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2 -mx-2 px-2">
          {[
            { id: 1, name: 'Fresh Carrots', price: 80, oldPrice: 95, img: 'https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png', weight: '500g', discount: 16, rating: 4.8, reviews: 124 },
            { id: 2, name: 'Premium Potatoes', price: 45, oldPrice: 55, img: 'https://i.postimg.cc/d1vdTWyL/1000020583-removebg-preview.png', weight: '1 KG', discount: 18, rating: 4.6, reviews: 89 },
            { id: 3, name: 'Fresh Tomatoes', price: 60, oldPrice: 75, img: 'https://i.postimg.cc/mr7CkxtQ/1000020584-removebg-preview.png', weight: '500g', discount: 20, rating: 4.9, reviews: 156 },
            { id: 4, name: 'Red Apples', price: 90, oldPrice: 110, img: 'https://i.postimg.cc/x1wL9jTV/IMG-20260228-163137.png', weight: '1 KG', discount: 18, rating: 4.7, reviews: 203 },
          ].map((item) => (
            <div 
              key={item.id} 
              onClick={() => setView('product')} 
              className="flex-shrink-0 w-[180px] bg-white rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer overflow-hidden group border border-gray-100"
            >
              {/* Image Container with Gradient Overlay */}
              <div className="relative h-[140px] bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center overflow-hidden">
                {/* Discount Badge */}
                <div className="absolute top-2 left-2 bg-gradient-to-r from-orange-500 to-red-500 text-white text-[10px] font-bold px-2 py-1 rounded-full shadow-md z-10">
                  -{item.discount}%
                </div>
                {/* Wishlist Button */}
                <button 
                  className="absolute top-2 right-2 w-7 h-7 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center shadow-sm opacity-0 group-hover:opacity-100 transition-opacity z-10 hover:bg-white hover:text-red-500"
                  onClick={(e) => e.stopPropagation()}
                >
                  <i className="ri-heart-line text-sm"></i>
                </button>
                {/* Product Image with Hover Effect */}
                <img 
                  src={item.img} 
                  alt={item.name} 
                  className="w-[100px] h-[100px] object-contain transition-transform duration-300 group-hover:scale-110" 
                  loading="lazy"
                />
              </div>
              
              {/* Product Info */}
              <div className="p-3">
                {/* Rating */}
                <div className="flex items-center gap-1 mb-1.5">
                  <div className="flex items-center gap-0.5">
                    {[1,2,3,4,5].map(star => (
                      <i 
                        key={star} 
                        className={`ri-star-${star <= Math.floor(item.rating) ? 'fill' : 'line'} text-yellow-400`}
                        style={{fontSize: '10px'}}
                      ></i>
                    ))}
                  </div>
                  <span className="text-[10px] text-gray-400">({item.reviews})</span>
                </div>
                
                {/* Product Name */}
                <h3 className="text-sm font-semibold text-gray-800 truncate mb-0.5 group-hover:text-[#16a34a] transition-colors">{item.name}</h3>
                
                {/* Weight */}
                <span className="text-[10px] text-gray-400 block mb-2">{item.weight}</span>
                
                {/* Price Row */}
                <div className="flex items-center justify-between">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-base font-bold text-[#16a34a]">TK{item.price}</span>
                    <span className="text-[10px] text-gray-400 line-through">TK{item.oldPrice}</span>
                  </div>
                  {/* Quick Add Button */}
                  <button 
                    className="w-8 h-8 bg-[#16a34a] text-white rounded-full flex items-center justify-center shadow-md hover:bg-[#15803d] transition-colors transform hover:scale-110"
                    onClick={(e) => {
                      e.stopPropagation();
                      addToCart({ id: item.id, name: item.name, price: item.price, oldPrice: item.oldPrice, img: item.img, weight: item.weight });
                    }}
                  >
                    <i className="ri-add-line text-lg"></i>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center p-5">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setIsModalOpen(false)}></div>
          <div className="relative bg-white w-full max-w-sm rounded-2xl shadow-2xl p-6">
            <h3 className="text-center text-lg font-bold text-[#1F2937] mb-4">Write a Review</h3>
            <div className="flex justify-center gap-2 mb-6">
              {[1,2,3,4,5].map(i => (
                <i key={i} className={`ri-star-${i <= userRating ? 'fill' : 'line'} text-2xl cursor-pointer transition-colors ${i <= userRating ? 'text-yellow-400' : 'text-gray-300 hover:text-yellow-400'}`} onClick={() => setUserRating(i)}></i>
              ))}
            </div>
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Your Name</label>
                <input id="reviewName" type="text" className="w-full bg-gray-50 border border-gray-100 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-[#16a34a]" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Review</label>
                <textarea id="reviewText" rows={3} className="w-full bg-gray-50 border border-gray-100 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-[#16a34a] resize-none"></textarea>
              </div>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setIsModalOpen(false)} className="flex-1 py-3 rounded-xl text-sm font-bold text-gray-500 bg-gray-50 hover:bg-gray-100">Cancel</button>
              <button onClick={handleSubmitReview} className="flex-1 py-3 rounded-xl text-sm font-bold text-white bg-[#16a34a] shadow-lg hover:opacity-90">Submit</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// 5. CART
const Cart = ({ setView, cartItems, setCartItems }: { setView: (v: string) => void; cartItems: CartItem[]; setCartItems: (items: CartItem[]) => void }) => {
  if (cartItems.length === 0) {
    return (
      <main className="flex flex-col items-center justify-center h-[calc(100vh-120px)] px-6 space-y-20 bg-white font-inter">
        <div className="flex flex-col items-center gap-1.5">
          <i className="ph ph-squares-four text-[56px] text-zinc-100"></i>
          <div className="text-center">
            <h1 className="text-xl font-medium tracking-tight text-zinc-900">Your cart is empty</h1>
            <p className="text-sm text-zinc-400 font-light max-w-[220px] mx-auto leading-relaxed">Add some fresh groceries to start your order.</p>
            <button onClick={()=>setView('shop')} className="mt-4 px-6 py-2 bg-[#16a34a] text-white rounded-lg text-sm font-medium">Shop Now</button>
          </div>
        </div>
      </main>
    )
  }

  const subtotal = cartItems.reduce((acc, item) => acc + item.price, 0)
  const tax = subtotal * 0.05
  const total = subtotal + tax + 50 

  return (
    <div className="cart-wrapper-container">
      <div className="cart-wrapper">
        <div className="cart-items-list">
          {cartItems.map((item, index) => (
            <div key={index} className="c12-item">
              <img src={item.img} className="c12-img" alt={item.name} />
              <div className="c12-info">
                <div className="c12-name-row"><span className="c12-name">{item.name}</span> <span className="c12-weight">({item.weight})</span></div>
                <div className="c12-action-row">
                  <div className="c12-price">TK {item.price}</div>
                  <div className="c12-qty-group">
                    <button className="c12-qbtn"><i className="ph ph-minus"></i></button>
                    <span className="c12-qval">1</span>
                    <button className="c12-qbtn"><i className="ph ph-plus"></i></button>
                  </div>
                </div>
              </div>
              <button className="c12-del" onClick={() => {
                const newItems = [...cartItems]
                newItems.splice(index, 1)
                setCartItems(newItems)
              }}><i className="ph ph-trash"></i></button>
            </div>
          ))}
        </div>
        <div className="order-summary">
          <div className="os-row"><span>Subtotal</span><span>TK {subtotal.toFixed(2)}</span></div>
          <div className="os-row"><span>Tax (5%)</span><span>TK {tax.toFixed(2)}</span></div>
          <div className="os-row"><span>Shipping</span><span className="os-shipping-text">Calculated at checkout</span></div>
          <div className="os-row total"><span>Total</span><span>TK {total.toFixed(2)}</span></div>
        </div>
        <div className="cart-buttons">
          <button className="cart-btn btn-continue" onClick={() => setView('shop')}>Continue</button>
          <button className="cart-btn btn-checkout" onClick={() => setView('checkout')}>Checkout</button>
        </div>
      </div>
    </div>
  )
}

// 6. CHECKOUT
const Checkout = ({ setView, onConfirm }: { setView: (v: string) => void; onConfirm: () => void }) => {
  const [address, setAddress] = useState('')
  const [focusedField, setFocusedField] = useState<string | null>(null)

  const isDeliveryKnown = address.length > 0
  const totalAmount = isDeliveryKnown ? 'TK140' : 'TK80'

  return (
    <div className="chk-bg">
      <div className="chk-container">
        {/* 1. Order Summary */}
        <div className="chk-section-header"><i className="ri-shopping-bag-3-line"></i> Order Summary</div>
        <div className="chk-product-row">
          <img src="https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png" alt="Carrot" className="chk-prod-img" />
          <div className="chk-prod-info"><h4>Organic Carrots</h4><span>Qty: 1 KG</span></div>
          <div className="chk-prod-price">TK80</div>
        </div>
        <div className="chk-cost-row"><span>Subtotal</span><span>TK80.00</span></div>
        <div className="chk-cost-row"><span>Delivery Charge</span><span>{isDeliveryKnown ? 'TK60.00' : '?'}</span></div>
        <div className="chk-total-row"><span>Total Payable</span><span>{totalAmount}.00</span></div>

        {/* Coupon Code */}
        <div className="chk-coupon-wrapper">
          <div className="chk-input-wrapper">
            <i className="ri-ticket-2-line chk-input-icon"></i>
            <input type="text" id="coupon" className="chk-clean-input" 
              onFocus={() => setFocusedField('coupon')} 
              onBlur={() => setFocusedField(null)} />
            <label htmlFor="coupon" className={`chk-input-label ${focusedField === 'coupon' ? 'active-label' : ''}`}>Coupon Code</label>
          </div>
          <button className="chk-btn-apply">APPLY</button>
        </div>

        <hr className="chk-divider" />

        {/* 2. Customer Information */}
        <div className="chk-section-header"><i className="ri-user-line"></i> Customer Information</div>
        <div className="chk-input-wrapper">
          <i className="ri-user-3-line chk-input-icon"></i>
          <input type="text" id="fullname" className="chk-clean-input" 
            onFocus={() => setFocusedField('fullname')} 
            onBlur={() => setFocusedField(null)} />
          <label htmlFor="fullname" className={`chk-input-label ${focusedField === 'fullname' ? 'active-label' : ''}`}>Full Name</label>
        </div>
        <div className="chk-input-wrapper">
          <i className="ri-smartphone-line chk-input-icon"></i>
          <input type="tel" id="phone" className="chk-clean-input" 
            onFocus={() => setFocusedField('phone')} 
            onBlur={() => setFocusedField(null)} />
          <label htmlFor="phone" className={`chk-input-label ${focusedField === 'phone' ? 'active-label' : ''}`}>Phone Number</label>
        </div>
        <div className="chk-input-wrapper">
          <i className="ri-map-pin-2-line chk-input-icon"></i>
          <input type="text" id="address" className="chk-clean-input" 
            onChange={(e)=>setAddress(e.target.value)} 
            onFocus={() => setFocusedField('address')} 
            onBlur={() => setFocusedField(null)} />
          <label htmlFor="address" className={`chk-input-label ${focusedField === 'address' ? 'active-label' : ''}`}>Full Address</label>
        </div>

        <hr className="chk-divider" />

        {/* 3. Payment Method */}
        <div className="chk-section-header"><i className="ri-secure-payment-line"></i> Payment Method</div>
        
        <div className="mt-4">
          <p style={{fontSize: '13px', color: '#475569', lineHeight: 1.6}}>
            This is a cash on delivery order. Please keep <b style={{color: '#0f172a'}}>{totalAmount}</b> ready to pay the rider when your order arrives.
          </p>
        </div>

        <hr className="chk-divider" />

        <div className="chk-legal-check"><input type="checkbox" id="save" /><label htmlFor="save">Save info for next time</label></div>
        <div className="chk-legal-check"><input type="checkbox" id="terms" /><label htmlFor="terms">I agree to the <a href="#" className="chk-link">Terms & Conditions</a></label></div>

        <div className="chk-btn-group">
          <button className="chk-btn-main chk-btn-cancel" onClick={() => setView('cart')}>Cancel</button>
          <button className="chk-btn-main chk-btn-confirm" onClick={onConfirm}>Confirm Order</button>
        </div>
      </div>
    </div>
  )
}

// 7. ORDER HISTORY
const Orders = ({ orders, setView }: { orders: { id: string }[]; setView: (v: string) => void }) => {
  if (orders.length === 0) {
    return (
      <main className="flex flex-col items-center justify-center h-[calc(100vh-120px)] px-6 space-y-20 bg-white font-inter">
        <div className="flex flex-col items-center gap-1.5">
          <i className="ri-todo-line text-[56px] text-zinc-100"></i>
          <div className="text-center">
            <h1 className="text-xl font-medium tracking-tight text-zinc-900">No orders yet</h1>
            <p className="text-sm text-zinc-400 font-light max-w-[220px] mx-auto leading-relaxed">Your past orders will appear here. Start shopping to place your first order.</p>
            <button onClick={()=>setView('shop')} className="mt-4 px-6 py-2 bg-[#16a34a] text-white rounded-lg text-sm font-medium">Shop Now</button>
          </div>
        </div>
      </main>
    )
  }

  return (
    <div className="min-h-[calc(100vh-120px)] flex items-center justify-center bg-gray-100 p-6 font-print antialiased text-[#111827] relative">
      <div className="w-full max-w-[340px] bg-white rounded-[5px] border border-[#111827]/20 flex flex-col overflow-hidden shadow-sm z-10">
        <div className="px-6 pt-7 pb-3 flex items-start gap-4">
          <div className="relative">
            <div className="absolute -top-[2px] -left-[2px] w-2 h-2 border-t-2 border-l-2 border-[#111827]"></div>
            <div className="absolute -top-[2px] -right-[2px] w-2 h-2 border-t-2 border-r-2 border-[#111827]"></div>
            <div className="absolute -bottom-[2px] -left-[2px] w-2 h-2 border-b-2 border-l-2 border-[#111827]"></div>
            <div className="absolute -bottom-[2px] -right-[2px] w-2 h-2 border-b-2 border-r-2 border-[#111827]"></div>
            <div className="w-14 h-14 bg-white p-1">
              <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=Order:45921&color=111827" className="w-full h-full object-contain" alt="Order QR" />
            </div>
          </div>
          <div className="flex flex-col pt-1">
            <span className="text-[10px] font-bold text-[#111827]/40 uppercase tracking-widest mb-0.5">Order History</span>
            <h2 className="text-sm font-bold tracking-tight uppercase">ID: #ORD-45921</h2>
            <div className="flex items-center gap-1.5 mt-2 text-[#F97316]">
              <i className="ph-bold ph-circle-notch text-xs"></i>
              <span className="text-[10px] font-bold uppercase tracking-widest">Processing</span>
            </div>
          </div>
        </div>

        <div className="px-6 py-5">
          <div className="relative flex items-center justify-between z-0">
            <div className="absolute top-1/2 left-0 w-full h-[2px] bg-[#111827]/10 -z-10 rounded-full"></div>
            <div className="absolute top-1/2 left-0 w-[66%] h-[2px] bg-[#F97316] -z-10 rounded-full"></div>
            <div className="bg-white pr-1"><div className="w-2.5 h-2.5 rounded-full bg-[#F97316]"></div></div>
            <div className="bg-white px-1"><div className="w-2.5 h-2.5 rounded-full bg-[#F97316]"></div></div>
            <div className="bg-white px-1"><div className="w-2.5 h-2.5 rounded-full border-2 border-[#F97316] bg-white ring-2 ring-[#F97316]/20"></div></div>
            <div className="bg-white pl-1"><div className="w-2.5 h-2.5 rounded-full bg-[#111827]/10"></div></div>
          </div>
          <div className="flex justify-between text-[9px] font-bold mt-2 uppercase text-[#111827]/40">
            <span className="text-[#111827]/80">Taken</span><span className="text-[#111827]/80">Packed</span><span className="text-[#F97316]">Process</span><span>Done</span>
          </div>
        </div>

        <div className="px-6 pb-6 pt-2">
          <div className="flex flex-col gap-4">
            <div className="flex items-start gap-3">
              <i className="ph-fill ph-map-pin text-sm text-[#111827]/30 mt-0.5"></i>
              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-[#111827]/40 uppercase tracking-widest mb-1">Shipping Details</span>
                <span className="text-xs font-bold text-[#111827] uppercase">Anamul Haque</span>
                <span className="text-xs font-bold text-[#111827]/60 mt-0.5 leading-snug uppercase">House 42, Road 9, Mirpur DOHS</span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <i className="ph-fill ph-timer text-sm text-[#F97316]"></i>
              <span className="text-xs font-bold text-[#F97316] uppercase tracking-tight">Est: 1 - 7 Days</span>
            </div>
          </div>
        </div>

        <div className="px-6 py-5 space-y-4 border-t border-dashed border-[#111827]/10 bg-gray-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-[3px] bg-white flex-shrink-0 overflow-hidden border border-[#111827]/10 p-[2px]">
              <img src="https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png" className="w-full h-full object-contain rounded-[2px]" alt="Carrot product" />
            </div>
            <div className="flex-1">
              <p className="text-xs font-bold tracking-tight uppercase text-[#111827]">Miniket Rice (5kg)</p>
              <p className="text-[9px] text-[#111827]/40 mt-0.5 uppercase">Qty: 1 Pack</p>
            </div>
            <span className="text-xs font-bold text-[#111827]">420TK</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-[3px] bg-white flex-shrink-0 overflow-hidden border border-[#111827]/10 p-[2px]">
              <img src="https://i.postimg.cc/d1vdTWyL/1000020583-removebg-preview.png" className="w-full h-full object-contain rounded-[2px]" alt="Potato product" />
            </div>
            <div className="flex-1">
              <p className="text-xs font-bold tracking-tight uppercase text-[#111827]">Soybean Oil (2L)</p>
              <p className="text-[9px] text-[#111827]/40 mt-0.5 uppercase">Qty: 2 Bottles</p>
            </div>
            <span className="text-xs font-bold text-[#111827]">390TK</span>
          </div>
        </div>

        <div className="px-6 pb-8 pt-5 border-t border-dashed border-[#111827]/20">
          <div className="space-y-2 mb-5">
            <div className="flex justify-between text-[11px] font-bold"><span className="text-[#111827]/40 uppercase">Sub-Total</span><span className="text-[#111827]">810TK</span></div>
            <div className="flex justify-between text-[11px] font-bold"><span className="text-[#111827]/40 uppercase tracking-tighter">Discount (SAVE50)</span><span className="text-[#111827]">-50TK</span></div>
            <div className="flex justify-between text-[11px] font-bold"><span className="text-[#111827]/40 uppercase">Delivery</span><span className="text-[#111827]">60TK</span></div>
          </div>
          <div className="w-full h-[1px] bg-[#111827]/10 mb-5"></div>
          <div className="flex justify-between items-center">
            <div className="flex flex-col">
              <span className="text-xs font-bold uppercase tracking-widest text-[#111827]/80">Payable Amount</span>
              <span className="text-[10px] font-bold text-[#111827]/40 uppercase mt-1">(Cash on Delivery)</span>
            </div>
            <div className="text-right"><span className="text-2xl font-bold tracking-tighter text-[#111827]">820TK</span></div>
          </div>
        </div>
      </div>
    </div>
  )
}

// 8. ADMIN DASHBOARD
const AdminDashboard = ({ setView }: { setView: (v: string) => void }) => {
  const [dashView, setDashView] = useState('overview')
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  
  const [inventory, setInventory] = useState<InventoryItem[]>([
    { id: 1, name: "Fresh Carrots", category: "Vegetables", image: "https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png", variants: [{ name: "250g", stock: 45, initialStock: 100 }, { name: "500g", stock: 32, initialStock: 80 }, { name: "1 KG", stock: 18, initialStock: 50 }], lastEdited: "Feb 25, 2026" },
    { id: 2, name: "Premium Potatoes", category: "Vegetables", image: "https://i.postimg.cc/d1vdTWyL/1000020583-removebg-preview.png", variants: [{ name: "500g", stock: 28, initialStock: 60 }, { name: "1 KG", stock: 55, initialStock: 100 }, { name: "2 KG", stock: 12, initialStock: 30 }], lastEdited: "Feb 24, 2026" },
    { id: 3, name: "Fresh Tomatoes", category: "Vegetables", image: "https://i.postimg.cc/mr7CkxtQ/1000020584-removebg-preview.png", variants: [{ name: "250g", stock: 8, initialStock: 40 }, { name: "500g", stock: 15, initialStock: 50 }, { name: "1 KG", stock: 22, initialStock: 60 }], lastEdited: "Feb 23, 2026" },
    { id: 4, name: "Red Apples", category: "Fruits", image: "https://i.postimg.cc/x1wL9jTV/IMG-20260228-163137.png", variants: [{ name: "500g", stock: 35, initialStock: 80 }, { name: "1 KG", stock: 48, initialStock: 100 }], lastEdited: "Feb 22, 2026" },
    { id: 5, name: "Fresh Bananas", category: "Fruits", image: "https://i.postimg.cc/bw71qYYK/IMG-20260228-163147.png", variants: [{ name: "6 pcs", stock: 42, initialStock: 80 }, { name: "1 Dozen", stock: 28, initialStock: 50 }], lastEdited: "Feb 21, 2026" },
    { id: 6, name: "Organic Spinach", category: "Vegetables", image: "https://i.postimg.cc/MG1VHkvz/1000020586-removebg-preview.png", variants: [{ name: "1 Bundle", stock: 5, initialStock: 25 }], lastEdited: "Feb 20, 2026" },
    { id: 7, name: "Sweet Oranges", category: "Fruits", image: "https://i.postimg.cc/mr7Ckxtx/IMG-20260228-163156.png", variants: [{ name: "500g", stock: 30, initialStock: 70 }, { name: "1 KG", stock: 45, initialStock: 80 }], lastEdited: "Feb 19, 2026" },
    { id: 8, name: "Grapes Green", category: "Fruits", image: "https://i.postimg.cc/htkVK4PD/IMG-20260228-163208.png", variants: [{ name: "250g", stock: 3, initialStock: 20 }, { name: "500g", stock: 18, initialStock: 40 }], lastEdited: "Feb 18, 2026" },
  ])
  const [expandedInventory, setExpandedInventory] = useState<number | null>(null)
  const [editingInventoryItem, setEditingInventoryItem] = useState<InventoryItem | null>(null)

  const [alerts] = useState<Alert[]>([
    { title: "Low Stock Alert", desc: "Sourdough Loaf is running low.", type: "danger" },
    { title: "Expiry Warning", desc: "3 items expire tomorrow.", type: "warning" },
    { title: "New Order", desc: "Order #402 placed online.", type: "info" },
  ])

  // Reviews Management State
  const [adminReviews, setAdminReviews] = useState<AdminReview[]>([
    { id: 1, product: 'Fresh Carrots', productCategory: 'Vegetables', productImg: 'https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png', customerName: 'Joya Parvin', rating: 5, text: 'Super fresh! My kids loved them. Will definitely order again.', date: 'Feb 24, 2026', time: '3:42 PM' },
    { id: 2, product: 'Premium Potatoes', productCategory: 'Vegetables', productImg: 'https://i.postimg.cc/d1vdTWyL/1000020583-removebg-preview.png', customerName: 'Ahmed Rahman', rating: 4, text: 'Good quality but delivery took time. Product was fresh though.', date: 'Feb 23, 2026', time: '1:15 PM' },
    { id: 3, product: 'Red Apples', productCategory: 'Fruits', productImg: 'https://i.postimg.cc/x1wL9jTV/IMG-20260228-163137.png', customerName: 'Fatima Khatun', rating: 5, text: 'Best apples I have ever had! Sweet and crispy.', date: 'Feb 22, 2026', time: '10:30 AM' },
    { id: 4, product: 'Fresh Tomatoes', productCategory: 'Vegetables', productImg: 'https://i.postimg.cc/mr7CkxtQ/1000020584-removebg-preview.png', customerName: 'Karim Uddin', rating: 2, text: 'Some tomatoes were damaged. Not happy with packaging.', date: 'Feb 21, 2026', time: '5:00 PM' },
    { id: 5, product: 'Organic Spinach', productCategory: 'Vegetables', productImg: 'https://i.postimg.cc/MG1VHkvz/1000020586-removebg-preview.png', customerName: 'Nasreen Akter', rating: 4, text: 'Very fresh and organic as promised. Recommended!', date: 'Feb 20, 2026', time: '11:20 AM' },
    { id: 6, product: 'Fresh Carrots', productCategory: 'Vegetables', productImg: 'https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png', customerName: 'Rafiq Islam', rating: 3, text: 'Average quality. Expected better for the price.', date: 'Feb 19, 2026', time: '2:45 PM' },
  ])

  const [isModalOpen, setIsModalOpen] = useState(false)
  const [newProduct, setNewProduct] = useState({ name: '', stock: '' })

  // Category Management State
  const [categories, setCategories] = useState<Category[]>([
    { id: 'CAT-101', name: 'Organic Fruits', type: 'icon', icon: 'ri-leaf-line', image: '', items: 24, created: '2 days ago', status: 'Active' },
    { id: 'CAT-102', name: 'Daily Essentials', type: 'icon', icon: 'ri-basket-line', image: '', items: 12, created: '5 days ago', status: 'Hidden' },
    { id: 'CAT-103', name: 'Fresh Vegetables', type: 'image', icon: '', image: 'https://i.postimg.cc/mr7CkxtQ/1000020584-removebg-preview.png', items: 36, created: '1 week ago', status: 'Active' }
  ])
  const [editingCategory, setEditingCategory] = useState<Category | null>(null)
  const [showToast, setShowToast] = useState(false)
  const [toastMsg, setToastMsg] = useState('')

  // Product Management State
  const [products, setProducts] = useState<Product[]>([
    { id: 1, name: 'Fresh Carrots', category: 'Vegetables', image: 'https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png', variants: '2 variants', price: 'TK80 – TK150', discount: '16%', offer: true, status: 'active' },
    { id: 2, name: 'Premium Potatoes', category: 'Vegetables', image: 'https://i.postimg.cc/d1vdTWyL/1000020583-removebg-preview.png', variants: '1 variant', price: 'TK45', discount: '0%', offer: false, status: 'active' },
    { id: 3, name: 'Red Apples', category: 'Fruits', image: 'https://i.postimg.cc/x1wL9jTV/IMG-20260228-163137.png', variants: '3 variants', price: 'TK90 – TK170', discount: '18%', offer: true, status: 'inactive' }
  ])
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [prodVarieties, setProdVarieties] = useState<{id: number}[]>([])
  const [prodFaqs, setProdFaqs] = useState<{id: number}[]>([])
  const [prodImages, setProdImages] = useState<string[]>([])
  const [prodRelated, setProdRelated] = useState<number[]>([])
  
  const allRelatedOptions = [
    {id:1,name:'Organic Bananas',category:'Fruits',price:2.50,image:'https://via.placeholder.com/80/FFC107/FFFFFF?text=B'},
    {id:2,name:'Whole Milk 1L',category:'Dairy',price:3.20,image:'https://via.placeholder.com/80/3B82F6/FFFFFF?text=M'},
    {id:3,name:'Brown Eggs',category:'Dairy',price:4.99,image:'https://via.placeholder.com/80/F97316/FFFFFF?text=E'},
    {id:4,name:'Wheat Bread',category:'Bakery',price:2.80,image:'https://via.placeholder.com/80/A16207/FFFFFF?text=B'},
  ]

  const handleAddProductInventory = (e: React.FormEvent) => {
    e.preventDefault()
    if(!newProduct.name || !newProduct.stock) return
    const qty = parseInt(newProduct.stock)
    const status = qty > 50 ? 'High' : (qty > 20 ? 'Med' : 'Low')
    const newItem: InventoryItem = { name: newProduct.name, stock: qty, status: status, trend: 'up' }
    setInventory([newItem, ...inventory])
    setNewProduct({ name: '', stock: '' })
    setIsModalOpen(false)
  }

  const chartData = [
    { day: 'Mon', height: '40%' }, { day: 'Tue', height: '65%', active: true }, { day: 'Wed', height: '55%' },
    { day: 'Thu', height: '80%' }, { day: 'Fri', height: '70%' }, { day: 'Sat', height: '90%' }, { day: 'Sun', height: '50%' }
  ]

  // Category Functions
  const openCategoryEdit = (cat: Category | null = null) => {
    if (cat) {
      setEditingCategory({ ...cat, type: cat.type })
    } else {
      setEditingCategory({
        id: 'CAT-' + Math.floor(Math.random() * 1000), name: '', type: 'icon', icon: '', image: '', items: 0, created: 'Just now', status: 'Active'
      })
    }
  }

  const handleSaveCategory = () => {
    if (!editingCategory?.name) { showToastMsg('Please enter a category name'); return }
    const exists = categories.find(c => c.id === editingCategory.id)
    let updatedCategories
    if (exists) {
      updatedCategories = categories.map(c => c.id === editingCategory.id ? { ...editingCategory } : c)
    } else {
      updatedCategories = [...categories, { ...editingCategory }]
    }
    setCategories(updatedCategories)
    setEditingCategory(null)
    showToastMsg('Category Updated Successfully!')
  }

  const handleDeleteCategory = (id: string) => {
    if(confirm("Delete this category?")) setCategories(categories.filter(c => c.id !== id))
  }

  // Product Functions
  const openProductEdit = (prod: Product | null = null) => {
    if (prod) {
      setEditingProduct({ ...prod, shortDesc: 'Fresh and crispy...', longDesc: '', offerSwitch: prod.offer })
    } else {
      setEditingProduct({
        id: Date.now(), name: '', category: '', image: 'https://via.placeholder.com/80', variants: '0 variants', price: '$0.00', discount: '0%', offer: false, status: 'active', shortDesc: '', longDesc: '', offerSwitch: false
      })
    }
    setProdVarieties([])
    setProdFaqs([])
    setProdImages([])
    setProdRelated([])
  }

  const handleSaveProduct = () => {
    if (!editingProduct?.name) { showToastMsg('Please enter product name'); return }
    const exists = products.find(p => p.id === editingProduct.id)
    let updatedProducts
    const finalProd = { ...editingProduct, offer: editingProduct.offerSwitch }
    
    if (exists) {
      updatedProducts = products.map(p => p.id === editingProduct.id ? finalProd : p)
    } else {
      updatedProducts = [...products, finalProd]
    }
    setProducts(updatedProducts)
    setEditingProduct(null)
    showToastMsg('Product Updated Successfully!')
  }

  const toggleProdStatus = (id: number) => {
    setProducts(products.map(p => p.id === id ? { ...p, status: p.status === 'active' ? 'inactive' : 'active' } : p))
  }

  const addVariety = () => setProdVarieties(prev => [...prev, { id: Date.now() }])
  const addFaq = () => setProdFaqs(prev => [...prev, { id: Date.now() }])
  const toggleRelated = (id: number) => {
    if (prodRelated.includes(id)) setProdRelated(prodRelated.filter(i => i !== id))
    else if (prodRelated.length < 4) setProdRelated([...prodRelated, id])
  }

  const showToastMsg = (msg: string) => {
    setToastMsg(msg)
    setShowToast(true)
    setTimeout(() => setShowToast(false), 2200)
  }

  // Order Management State
  const [orders, setOrders] = useState<Order[]>([
    { 
      id: 'ORD-POTATO', 
      customer: 'Raihan', 
      phone: '+8801866228213', 
      address: 'Gulshan 2, Road 45, House 12, Dhaka',
      date: 'Feb 24, 2026',
      time: '10 min ago',
      paymentMethod: 'Cash on Delivery',
      status: 'pending',
      courierStatus: 'Processing',
      subtotal: 5850,
      delivery: 150,
      discount: 100,        
      couponCodes: ['FIRST10'], 
      couponAmount: 50,     
      total: 5850 + 150 - 100 - 50,
      canceledBy: null,
      items: [
        { name: 'Organic Milk', variant: '1L', qty: 2, basePrice: 150, offerText: '5% off', offerDiscount: 7.5, couponCode: null, couponDiscount: 0 }, 
        { name: 'Samsung Galaxy S24', variant: '256GB', qty: 1, basePrice: 4180, offerText: null, offerDiscount: 0, couponCode: 'NEWPHONE', couponDiscount: 100 }, 
        { name: 'Premium Coffee', variant: null, qty: 1, basePrice: 1370, offerText: '10% off', offerDiscount: 137, couponCode: 'COFFEE20', couponDiscount: 50 }, 
      ]
    },
    { 
      id: 'ORD-002', 
      customer: 'Sarah Johnson', 
      phone: '+8801987654321', 
      address: 'Dhanmondi, Road 8A, Dhaka',
      date: 'Feb 25, 2026',
      time: '25 min ago',
      paymentMethod: 'Pre-payment',
      status: 'approved',
      courierStatus: 'Shipping', 
      subtotal: 1650,
      delivery: 0,
      discount: 0,          
      couponCodes: [],        
      couponAmount: 0,
      total: 1650,
      canceledBy: null,
      items: [
        { name: 'Orange Juice', variant: '1L', qty: 2, basePrice: 600, offerText: null, offerDiscount: 0, couponCode: null, couponDiscount: 0 }, 
        { name: 'Apples', variant: '1kg', qty: 1, basePrice: 450, offerText: null, offerDiscount: 0, couponCode: null, couponDiscount: 0 }, 
      ]
    },
    { 
      id: 'ORD-003', 
      customer: 'Mike Wilson', 
      phone: '+8801555123456', 
      address: 'Banani, Block C, Dhaka',
      date: 'Feb 24, 2026',
      time: '1 hour ago',
      paymentMethod: 'Cash on Delivery',
      status: 'canceled',
      courierStatus: 'Canceled', 
      subtotal: 4200,
      delivery: 100,
      discount: 500,        
      couponCodes: [],        
      couponAmount: 0,
      total: 4200 - 500 + 100,
      canceledBy: 'Customer',
      items: [
        { name: 'Basmati Rice', variant: '5kg', qty: 1, basePrice: 1800, offerText: null, offerDiscount: 0, couponCode: null, couponDiscount: 0 }, 
        { name: 'Olive Oil', variant: '2L', qty: 2, basePrice: 1200, offerText: null, offerDiscount: 0, couponCode: null, couponDiscount: 0 }, 
      ]
    },
  ])
  const [currentOrderFilter, setCurrentOrderFilter] = useState<'all' | 'pending' | 'approved' | 'canceled'>('all')
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)

  const filteredOrders = currentOrderFilter === 'all' 
    ? orders 
    : orders.filter(order => order.status === currentOrderFilter)

  const updateOrderStatus = (id: string, status: 'approved' | 'canceled') => {
    setOrders(orders.map(order => {
      if (order.id === id) {
        return { 
          ...order, 
          status, 
          canceledBy: status === 'canceled' ? 'Admin' : null 
        }
      }
      return order
    }))
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    showToastMsg('Number Copied!')
  }

  // Coupon Management State
  const couponProducts: CouponProduct[] = [
    { id:1, name:'Fresh Carrots', price:'TK80', img:'https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png' },
    { id:2, name:'Premium Potatoes', price:'TK45', img:'https://i.postimg.cc/d1vdTWyL/1000020583-removebg-preview.png' },
    { id:3, name:'Fresh Tomatoes', price:'TK60', img:'https://i.postimg.cc/mr7CkxtQ/1000020584-removebg-preview.png' },
    { id:4, name:'Red Apples', price:'TK90', img:'https://i.postimg.cc/x1wL9jTV/IMG-20260228-163137.png' },
    { id:5, name:'Fresh Bananas', price:'TK50', img:'https://i.postimg.cc/bw71qYYK/IMG-20260228-163147.png' },
    { id:6, name:'Sweet Oranges', price:'TK80', img:'https://i.postimg.cc/mr7Ckxtx/IMG-20260228-163156.png' },
    { id:7, name:'Grapes Green', price:'TK120', img:'https://i.postimg.cc/htkVK4PD/IMG-20260228-163208.png' },
    { id:8, name:'Mango Fresh', price:'TK150', img:'https://i.postimg.cc/Z5G6JYKm/IMG-20260228-163217.png' },
  ]
  const couponCategories: CouponCategory[] = [
    { name:'Fruits & Vegetables', color:'#16a34a' },
    { name:'Dairy & Eggs',        color:'#2563eb' },
    { name:'Bakery',              color:'#d97706' },
    { name:'Meat & Seafood',      color:'#dc2626' },
    { name:'Beverages',           color:'#7c3aed' },
    { name:'Snacks',              color:'#0891b2' },
    { name:'Frozen Foods',        color:'#0284c7' },
  ]
  
  const [coupons, setCoupons] = useState<Coupon[]>([
    { id: '1', code: 'SUMMER20', type: 'pct', value: 20, scope: 'all', expiry: '2025-08-31' },
    { id: '2', code: 'FLAT15', type: 'fixed', value: 15, scope: 'products', expiry: '2025-07-15', selectedProducts: [1, 3] },
    { id: '3', code: 'BAKERY10', type: 'pct', value: 10, scope: 'categories', expiry: '', selectedCategories: ['Bakery'] },
    { id: '4', code: 'WELCOME50', type: 'fixed', value: 50, scope: 'all', expiry: '' },
  ])
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null)
  const [couponForm, setCouponForm] = useState({
    code: '',
    type: 'pct' as 'pct' | 'fixed',
    value: '',
    expiry: '',
    scope: 'all' as 'all' | 'products' | 'categories',
  })
  const [pickedProducts, setPickedProducts] = useState<number[]>([])
  const [pickedCategories, setPickedCategories] = useState<string[]>([])

  const openCouponEdit = (coupon: Coupon | null = null) => {
    if (coupon && coupon.id) {
      setCouponForm({
        code: coupon.code,
        type: coupon.type,
        value: coupon.value.toString(),
        expiry: coupon.expiry,
        scope: coupon.scope,
      })
      setPickedProducts(coupon.selectedProducts || [])
      setPickedCategories(coupon.selectedCategories || [])
      setEditingCoupon(coupon)
    } else {
      setCouponForm({ code: '', type: 'pct', value: '', expiry: '', scope: 'all' })
      setPickedProducts([])
      setPickedCategories([])
      setEditingCoupon({ id: '', code: '', type: 'pct', value: 0, scope: 'all', expiry: '' })
    }
  }

  const handleSaveCoupon = () => {
    if (!couponForm.code.trim()) { showToastMsg('Please enter a coupon code.'); return }
    if (!couponForm.value.trim()) { showToastMsg('Please enter a discount value.'); return }

    const newCoupon: Coupon = {
      id: editingCoupon?.id || Date.now().toString(),
      code: couponForm.code.toUpperCase(),
      type: couponForm.type,
      value: parseFloat(couponForm.value),
      scope: couponForm.scope,
      expiry: couponForm.expiry,
      selectedProducts: couponForm.scope === 'products' ? pickedProducts : undefined,
      selectedCategories: couponForm.scope === 'categories' ? pickedCategories : undefined,
    }

    if (editingCoupon?.id) {
      setCoupons(coupons.map(c => c.id === editingCoupon.id ? newCoupon : c))
      showToastMsg('Coupon updated!')
    } else {
      setCoupons([...coupons, newCoupon])
      showToastMsg('Coupon added!')
    }
    setEditingCoupon(null)
  }

  const deleteCoupon = (id: string) => {
    setCoupons(coupons.filter(c => c.id !== id))
    showToastMsg('Coupon deleted!')
  }

  const toggleProductPick = (id: number) => {
    if (pickedProducts.includes(id)) {
      setPickedProducts(pickedProducts.filter(p => p !== id))
    } else {
      setPickedProducts([...pickedProducts, id])
    }
  }

  const toggleCategoryPick = (name: string) => {
    if (pickedCategories.includes(name)) {
      setPickedCategories(pickedCategories.filter(c => c !== name))
    } else {
      setPickedCategories([...pickedCategories, name])
    }
  }

  const formatExpiry = (expiry: string) => {
    if (!expiry) return '[Not Applied]'
    const d = new Date(expiry + 'T00:00:00')
    return `[${d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}]`
  }

  // Abandoned Checkouts State
  const [abandonedCheckouts] = useState<AbandonedCheckout[]>([
    {
      id: 1, name: 'Rafi Hossain', phone: '+1 987 654 321',
      address: '555 Park Ave, Dhaka',
      visitTime: '15 min ago', visitDate: 'Feb 24, 2026 · 3:42 PM',
      totalVisits: 3, completedOrders: 1,
      history: [
        {
          date: 'Feb 24, 2026', time: '3:42 PM', timeAgo: '15 min ago', status: 'abandoned',
          products: [
            { name: 'Organic Milk', variants: [{ label: '500ml', qty: 2 }] },
            { name: 'Whole Wheat Bread', variants: [{ label: null, qty: 2 }] },
            { name: 'Farm Eggs', variants: [{ label: '12 pcs', qty: 1 }] },
            { name: 'Cheddar Cheese', variants: [{ label: '200g', qty: 1 }] },
          ],
          total: 45.92
        },
        {
          date: 'Feb 20, 2026', time: '5:10 PM', timeAgo: '4 days ago', status: 'abandoned',
          products: [{ name: 'Butter', variants: [{ label: '200g', qty: 1 }] }],
          total: 12.50
        },
        {
          date: 'Feb 18, 2026', time: '7:05 PM', timeAgo: '6 days ago', status: 'completed',
          products: [
            { name: 'Basmati Rice', variants: [{ label: '2kg', qty: 1 }] },
            { name: 'Soybean Oil', variants: [{ label: '1L', qty: 1 }] },
          ],
          total: 35.97
        },
      ]
    },
    {
      id: 2, name: 'Tariq Mahmud', phone: '+1 765 432 109',
      address: '888 River St, Chittagong',
      visitTime: '2 hours ago', visitDate: 'Feb 24, 2026 · 1:55 PM',
      totalVisits: 5, completedOrders: 2,
      history: [
        {
          date: 'Feb 24, 2026', time: '1:55 PM', timeAgo: '2 hours ago', status: 'abandoned',
          products: [
            { name: 'Basmati Rice', variants: [{ label: '1kg', qty: 3 }] },
            { name: 'Cooking Oil', variants: [{ label: '500ml', qty: 4 }] },
            { name: 'Lentils', variants: [{ label: 'Red', qty: 2 }] },
            { name: 'Spices', variants: [{ label: 'Mix', qty: 1 }] },
          ],
          total: 284.61
        },
        {
          date: 'Feb 22, 2026', time: '9:00 AM', timeAgo: '2 days ago', status: 'completed',
          products: [{ name: 'Salt', variants: [{ label: '1kg', qty: 2 }] }],
          total: 10.00
        },
        {
          date: 'Feb 15, 2026', time: '6:30 PM', timeAgo: '9 days ago', status: 'completed',
          products: [{ name: 'Sugar', variants: [{ label: '1kg', qty: 2 }] }],
          total: 22.15
        },
        {
          date: 'Feb 10, 2026', time: '12:00 PM', timeAgo: '2 weeks ago', status: 'abandoned',
          products: [{ name: 'Tea Leaves', variants: [{ label: '400g', qty: 1 }] }],
          total: 8.50
        },
        {
          date: 'Feb 05, 2026', time: '4:20 PM', timeAgo: '3 weeks ago', status: 'abandoned',
          products: [{ name: 'Biscuits', variants: [{ label: 'Pack', qty: 5 }] }],
          total: 15.20
        },
      ]
    },
    {
      id: 3, name: 'Sumaiya Akter', phone: '+1 654 321 098',
      address: '12 Green Rd, Sylhet',
      visitTime: '4 hours ago', visitDate: 'Feb 24, 2026 · 11:40 AM',
      totalVisits: 2, completedOrders: 1,
      history: [
        {
          date: 'Feb 24, 2026', time: '11:40 AM', timeAgo: '4 hours ago', status: 'abandoned',
          products: [
            { name: 'Yogurt', variants: [{ label: '150g', qty: 2 }] },
            { name: 'Milk', variants: [{ label: '1L', qty: 1 }] },
            { name: 'Honey', variants: [{ label: '250g', qty: 1 }] },
          ],
          total: 27.41
        },
        {
          date: 'Feb 20, 2026', time: '10:00 AM', timeAgo: '4 days ago', status: 'completed',
          products: [{ name: 'Apples', variants: [{ label: '1kg', qty: 1 }] }],
          total: 15.00
        }
      ]
    }
  ])
  const [expandedAbandoned, setExpandedAbandoned] = useState<number | null>(null)

  const getInitials = (name: string) => name.split(' ').map(w => w[0]).join('').toUpperCase()

  const buildEntries = (products: AbandonedProduct[]) => {
    const entries: { name: string; variant: string | null; qty: number }[] = []
    products.forEach(p => p.variants.forEach(v => entries.push({ name: p.name, variant: v.label, qty: v.qty })))
    return entries
  }

  const toggleAbandonedExpand = (id: number) => {
    setExpandedAbandoned(expandedAbandoned === id ? null : id)
  }

  // Customer Profile State
  const [customerProfiles] = useState<CustomerProfile[]>([
    {
      id: 1, name: 'Rafi Hossain', phone: '+8801712345678',
      address: '555 Park Ave, Dhaka',
      totalSpent: 450.50, totalOrders: 5,
      orders: [
        {
          date: 'Feb 24, 2026', time: '3:42 PM', timeAgo: '2 days ago', visitCount: 21,
          products: [
            { name: 'Organic Milk', variants: [{ label: '1L', qty: 2 }] },
            { name: 'Whole Wheat Bread', variants: [{ label: null, qty: 2 }] },
            { name: 'Farm Eggs', variants: [{ label: '12 pcs', qty: 1 }] },
          ],
          total: 45.92
        },
        {
          date: 'Feb 10, 2026', time: '5:10 PM', timeAgo: '2 weeks ago', visitCount: 15,
          products: [
            { name: 'Basmati Rice', variants: [{ label: '5kg', qty: 1 }] },
            { name: 'Soybean Oil', variants: [{ label: '2L', qty: 1 }] },
          ],
          total: 85.50
        },
      ]
    },
    {
      id: 2, name: 'Tariq Mahmud', phone: '+8801812345678',
      address: '888 River St, Chittagong',
      totalSpent: 1250.00, totalOrders: 12,
      orders: [
        {
          date: 'Feb 25, 2026', time: '10:00 AM', timeAgo: '5 hours ago', visitCount: 42,
          products: [
            { name: 'Beef Meat', variants: [{ label: '2kg', qty: 1 }] },
            { name: 'Chicken', variants: [{ label: 'Whole', qty: 2 }] },
            { name: 'Spices Mix', variants: [{ label: 'Pack', qty: 3 }] },
            { name: 'Onions', variants: [{ label: '5kg', qty: 1 }] },
          ],
          total: 320.00
        },
      ]
    },
    {
      id: 3, name: 'Sumaiya Akter', phone: '+8801912345678',
      address: '12 Green Rd, Sylhet',
      totalSpent: 85.00, totalOrders: 2,
      orders: [
        {
          date: 'Jan 20, 2026', time: '4:00 PM', timeAgo: '1 month ago', visitCount: 8,
          products: [
            { name: 'Face Wash', variants: [{ label: '100ml', qty: 1 }] },
            { name: 'Shampoo', variants: [{ label: '200ml', qty: 1 }] },
          ],
          total: 45.00
        }
      ]
    }
  ])
  const [expandedCustomer, setExpandedCustomer] = useState<number | null>(null)

  const toggleCustomerExpand = (id: number) => {
    setExpandedCustomer(expandedCustomer === id ? null : id)
  }

  // Settings State
  const [settings, setSettings] = useState<Settings>({
    websiteName: 'GroceryHub',
    slogan: 'Freshness at your door',
    faviconUrl: '',
    insideDhakaDelivery: 60,
    outsideDhakaDelivery: 120,
    freeDeliveryMin: 1000,
    whatsappNumber: '',
    phoneNumber: '',
    facebookUrl: '',
    messengerUsername: '',
    aboutUs: '',
    termsConditions: '',
    refundPolicy: '',
    privacyPolicy: ''
  })

  const handleSaveSettings = () => {
    showToastMsg('Settings saved successfully!')
  }

  // Credentials State
  const [credentials, setCredentials] = useState<Credentials>({
    username: 'admin_main',
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
    apiKey: 'pk_test_8f7d6a5s4d3f2g1h',
    secretKey: 'sk_test_1a2b3c4d5e6f7g8h',
    webhookUrl: 'https://myshop.com/webhooks/delivery'
  })

  const handleSaveAccount = (e: React.FormEvent) => {
    e.preventDefault()
    if (credentials.newPassword && credentials.newPassword !== credentials.confirmPassword) {
      showToastMsg('Passwords do not match!')
      return
    }
    setCredentials({...credentials, currentPassword: '', newPassword: '', confirmPassword: ''})
    showToastMsg('Account settings saved successfully!')
  }

  const handleSaveApi = (e: React.FormEvent) => {
    e.preventDefault()
    showToastMsg('API configurations saved successfully!')
  }

  const getOrdinal = (n: number) => {
    const s = ["th", "st", "nd", "rd"]
    const v = n % 100
    return s[(v - 20) % 10] || s[v] || s[0]
  }

  const copyToClipboardLocal = (text: string) => {
    navigator.clipboard.writeText(text)
    showToastMsg('Number copied!')
  }

  // Navigation items
  const navItems = [
    { id: 'overview', label: 'Overview', icon: 'ri-dashboard-line' },
    { id: 'orders', label: 'Orders', icon: 'ri-shopping-bag-line' },
    { id: 'products', label: 'Products', icon: 'ri-store-2-line' },
    { id: 'inventory', label: 'Inventory', icon: 'ri-archive-line' },
    { id: 'categories', label: 'Categories', icon: 'ri-folder-line' },
    { id: 'coupons', label: 'Coupons', icon: 'ri-ticket-2-line' },
    { id: 'reviews', label: 'Reviews', icon: 'ri-star-line' },
    { id: 'abandoned', label: 'Abandoned', icon: 'ri-alert-line' },
    { id: 'customers', label: 'Customers', icon: 'ri-user-line' },
  ]

  const configItems = [
    { id: 'settings', label: 'Settings', icon: 'ri-settings-3-line' },
    { id: 'credentials', label: 'Credentials', icon: 'ri-shield-keyhole-line' },
  ]

  const getPageTitle = () => {
    if (editingCategory) return 'Edit Category'
    if (editingProduct) return 'Edit Product'
    if (editingCoupon) return 'Edit Coupon'
    switch(dashView) {
      case 'overview': return 'Store Overview'
      case 'orders': return 'Order Management'
      case 'products': return 'Product Management'
      case 'inventory': return 'Inventory Management'
      case 'categories': return 'Category Management'
      case 'coupons': return 'Coupon Management'
      case 'reviews': return 'Review Management'
      case 'abandoned': return 'Abandoned Checkouts'
      case 'customers': return 'Customer History'
      case 'settings': return 'System Settings'
      case 'credentials': return 'Settings Configuration'
      default: return 'Dashboard'
    }
  }

  const getPageDesc = () => {
    if (editingCategory) return 'Modify category details and settings'
    if (editingProduct) return 'Update product information and variants'
    if (editingCoupon) return 'Adjust coupon rules and availability'
    switch(dashView) {
      case 'overview': return 'Performance metrics for October 24, 2023'
      case 'orders': return 'Detailed overview of all incoming requests'
      case 'products': return 'Manage your store items and inventory'
      case 'inventory': return 'Track and manage product stock levels'
      case 'categories': return 'Organize your product categories'
      case 'coupons': return 'Manage discount coupons for your store'
      case 'reviews': return 'Manage customer reviews and feedback'
      case 'abandoned': return 'Customers who visited but didn\'t complete checkout'
      case 'customers': return 'Overview of customer orders and spending'
      case 'settings': return 'Configure your store preferences and policies'
      case 'credentials': return 'Manage your account credentials and system integrations'
      default: return ''
    }
  }

  return (
    <div className="admin-layout" style={{fontFamily: "'Inter', ui-sans-serif, system-ui, sans-serif"}}>
      {/* Sidebar */}
      <aside className={`admin-sidebar ${sidebarCollapsed ? 'collapsed' : ''}`}>
        <div className="admin-sidebar-brand">
          <img src="https://i.postimg.cc/4xZk3k2j/IMG-20260226-120143.png" alt="Logo" style={{width: '32px', height: '32px', objectFit: 'contain'}} />
          <h2>Krishi Bitan</h2>
        </div>
        <button className="admin-sidebar-toggle" onClick={() => setSidebarCollapsed(!sidebarCollapsed)} title={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}>
          <i className="ri-arrow-left-s-line"></i>
        </button>
        
        <nav className="admin-sidebar-nav">
          <div className="admin-nav-section">
            <div className="admin-nav-section-title">Main Menu</div>
            {navItems.map(item => (
              <div 
                key={item.id}
                className={`admin-nav-item ${dashView === item.id && !editingCategory && !editingProduct && !editingCoupon ? 'active' : ''}`}
                onClick={() => { setDashView(item.id); setEditingCategory(null); setEditingProduct(null); setEditingCoupon(null); }}
                data-tooltip={item.label}
              >
                <i className={item.icon}></i>
                <span>{item.label}</span>
              </div>
            ))}
          </div>
          
          <div className="admin-nav-divider"></div>
          
          <div className="admin-nav-section">
            <div className="admin-nav-section-title">Configuration</div>
            {configItems.map(item => (
              <div 
                key={item.id}
                className={`admin-nav-item ${dashView === item.id ? 'active' : ''}`}
                onClick={() => { setDashView(item.id); setEditingCategory(null); setEditingProduct(null); setEditingCoupon(null); }}
                data-tooltip={item.label}
              >
                <i className={item.icon}></i>
                <span>{item.label}</span>
              </div>
            ))}
          </div>
        </nav>
        
        <div className="admin-sidebar-footer">
          <button className="admin-sidebar-add-btn" onClick={() => setIsModalOpen(true)} data-tooltip="Add Inventory">
            <i className="ri-add-line"></i>
            <span>Add Inventory</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="admin-main-content">
        {/* Page Header with Back button for editing states */}
        <div className="admin-page-header" style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start'}}>
          <div>
            {editingCategory || editingProduct || editingCoupon ? (
              <h1 style={{display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer'}} onClick={() => { setEditingCategory(null); setEditingProduct(null); setEditingCoupon(null); }}>
                <i className="ri-arrow-left-line" style={{fontSize: '20px'}}></i>
                {getPageTitle()}
              </h1>
            ) : (
              <h1>{getPageTitle()}</h1>
            )}
            <p>{getPageDesc()}</p>
          </div>
          <div style={{display: 'flex', gap: '12px', alignItems: 'center'}}>
            {/* Action buttons for specific views */}
            {(dashView === 'categories' && !editingCategory) && (
              <button className="btn-admin-minimal btn-admin-primary" onClick={() => openCategoryEdit()}>+ Add Category</button>
            )}
            {(dashView === 'products' && !editingProduct) && (
              <button className="btn-admin-minimal btn-admin-primary" onClick={() => openProductEdit()}>+ Add Product</button>
            )}
            {(dashView === 'coupons' && !editingCoupon) && (
              <button className="btn-admin-minimal btn-admin-primary" onClick={() => openCouponEdit()}>+ Add Coupon</button>
            )}
          </div>
        </div>

      {/* OVERVIEW DASHBOARD */}
      {dashView === 'overview' && !editingCategory && !editingProduct && (
        <>
          <section className="metrics">
            <div className="metric-card"><div className="metric-label">Revenue</div><div className="metric-value">$42,590</div><div className="metric-change trend-pos">↑ 12.5% <span style={{color: 'var(--admin-text-tertiary)', fontWeight: 400}}>vs last week</span></div></div>
            <div className="metric-card"><div className="metric-label">Orders</div><div className="metric-value">1,284</div><div className="metric-change trend-pos">↑ 4.2% <span style={{color: 'var(--admin-text-tertiary)', fontWeight: 400}}>vs last week</span></div></div>
            <div className="metric-card"><div className="metric-label">Avg. Order</div><div className="metric-value">$33.17</div><div className="metric-change trend-neg">↓ 0.8% <span style={{color: 'var(--admin-text-tertiary)', fontWeight: 400}}>vs last week</span></div></div>
            <div className="metric-card"><div className="metric-label">Waste</div><div className="metric-value">12.4 kg</div><div className="metric-change trend-pos">↓ 2.1% <span style={{color: 'var(--admin-text-tertiary)', fontWeight: 400}}>improvement</span></div></div>
          </section>
          
          {/* Recent Orders - Full Width */}
          <section style={{marginBottom: '24px'}}>
            <div className="panel">
              <div className="panel-header">
                <div className="panel-title">Recent Orders</div>
                <div style={{fontSize: '12px', color: 'var(--admin-primary)', cursor: 'pointer', fontWeight: 500}} onClick={() => setDashView('orders')}>View All →</div>
              </div>
              <div style={{overflowX: 'auto'}}>
                <table style={{width: '100%', fontSize: '13px'}}>
                  <thead style={{background: '#f8fafc', borderBottom: '1px solid #e2e8f0'}}>
                    <tr>
                      <th style={{textAlign: 'left', padding: '12px 16px', fontSize: '11px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em'}}>Order</th>
                      <th style={{textAlign: 'left', padding: '12px 16px', fontSize: '11px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em'}}>Customer</th>
                      <th style={{textAlign: 'left', padding: '12px 16px', fontSize: '11px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em'}}>Items</th>
                      <th style={{textAlign: 'left', padding: '12px 16px', fontSize: '11px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em'}}>Payment</th>
                      <th style={{textAlign: 'left', padding: '12px 16px', fontSize: '11px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em'}}>Total</th>
                      <th style={{textAlign: 'left', padding: '12px 16px', fontSize: '11px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em'}}>Status</th>
                      <th style={{textAlign: 'left', padding: '12px 16px', fontSize: '11px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em'}}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.slice(0, 5).map((order) => (
                      <tr key={order.id} style={{borderBottom: '1px solid #f1f5f9'}} onMouseEnter={(e) => e.currentTarget.style.background = '#f8fafc'} onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
                        <td style={{padding: '12px 16px', verticalAlign: 'middle'}}>
                          <span style={{fontFamily: 'monospace', fontSize: '13px', fontWeight: 600, color: '#0f172a'}}>{order.id}</span>
                          <div style={{fontSize: '11px', color: '#94a3b8', marginTop: '2px'}}>{order.time}</div>
                        </td>
                        <td style={{padding: '12px 16px', verticalAlign: 'middle'}}>
                          <div style={{fontWeight: 500, color: '#0f172a'}}>{order.customer}</div>
                          <div style={{fontSize: '11px', color: '#94a3b8'}}>{order.phone}</div>
                        </td>
                        <td style={{padding: '12px 16px', verticalAlign: 'middle'}}>
                          <div style={{fontSize: '12px', color: '#0f172a'}}>{order.items.length} items</div>
                        </td>
                        <td style={{padding: '12px 16px', verticalAlign: 'middle'}}>
                          <div style={{fontSize: '11px', fontWeight: 600, color: '#0f172a', textTransform: 'uppercase', letterSpacing: '0.02em'}}>{order.paymentMethod}</div>
                        </td>
                        <td style={{padding: '12px 16px', verticalAlign: 'middle'}}>
                          <span style={{fontSize: '13px', fontWeight: 600, color: '#16a34a'}}>TK{order.total.toLocaleString()}</span>
                        </td>
                        <td style={{padding: '12px 16px', verticalAlign: 'middle'}}>
                          {order.status === 'pending' && (
                            <span style={{display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '4px 10px', borderRadius: '20px', fontSize: '11px', fontWeight: 600, background: '#fef3c7', color: '#d97706'}}>
                              <span style={{width: '6px', height: '6px', borderRadius: '50%', background: '#d97706'}}></span>
                              Pending
                            </span>
                          )}
                          {order.status === 'approved' && (
                            <span style={{display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '4px 10px', borderRadius: '20px', fontSize: '11px', fontWeight: 600, background: '#d1fae5', color: '#16a34a'}}>
                              <span style={{width: '6px', height: '6px', borderRadius: '50%', background: '#16a34a'}}></span>
                              Approved
                            </span>
                          )}
                          {order.status === 'canceled' && (
                            <span style={{display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '4px 10px', borderRadius: '20px', fontSize: '11px', fontWeight: 600, background: '#fee2e2', color: '#dc2626'}}>
                              <span style={{width: '6px', height: '6px', borderRadius: '50%', background: '#dc2626'}}></span>
                              Canceled
                            </span>
                          )}
                        </td>
                        <td style={{padding: '12px 16px', verticalAlign: 'middle'}}>
                          {order.status === 'pending' && (
                            <div style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
                              <span 
                                onClick={() => setOrders(orders.map(o => o.id === order.id ? {...o, status: 'approved'} : o))} 
                                style={{color: '#16a34a', fontWeight: 700, fontSize: '11px', cursor: 'pointer'}}
                                onMouseEnter={(e) => e.currentTarget.style.textDecoration = 'underline'}
                                onMouseLeave={(e) => e.currentTarget.style.textDecoration = 'none'}
                              >Approve</span>
                              <span style={{color: '#cbd5e1', fontSize: '10px'}}>|</span>
                              <span 
                                onClick={() => setOrders(orders.map(o => o.id === order.id ? {...o, status: 'canceled'} : o))} 
                                style={{color: '#dc2626', fontWeight: 700, fontSize: '11px', cursor: 'pointer'}}
                                onMouseEnter={(e) => e.currentTarget.style.textDecoration = 'underline'}
                                onMouseLeave={(e) => e.currentTarget.style.textDecoration = 'none'}
                              >Reject</span>
                            </div>
                          )}
                          {order.status === 'approved' && (
                            <div>
                              <div style={{color: '#16a34a', fontWeight: 700, fontSize: '11px'}}>Approved</div>
                              <div style={{fontSize: '10px', color: '#94a3b8'}}>by Admin</div>
                            </div>
                          )}
                          {order.status === 'canceled' && (
                            <div>
                              <div style={{color: '#dc2626', fontWeight: 700, fontSize: '11px'}}>Canceled</div>
                              <div style={{fontSize: '10px', color: '#94a3b8'}}>by Admin</div>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
          
          {/* Product Stats Sections */}
          <section style={{display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '24px', marginBottom: '24px'}}>
            {/* Most Selling Products */}
            <div className="panel">
              <div className="panel-header">
                <div className="panel-title" style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
                  <i className="ri-fire-line" style={{color: '#ef4444'}}></i>
                  Most Selling
                </div>
              </div>
              <div style={{display: 'flex', flexDirection: 'column', gap: '6px'}}>
                {[
                  { name: 'Fresh Carrots', category: 'Vegetables', amount: '234', img: 'https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png' },
                  { name: 'Red Apples', category: 'Fruits', amount: '189', img: 'https://i.postimg.cc/x1wL9jTV/IMG-20260228-163137.png' },
                  { name: 'Fresh Bananas', category: 'Fruits', amount: '156', img: 'https://i.postimg.cc/bw71qYYK/IMG-20260228-163147.png' },
                ].map((item, i) => (
                  <div key={i} style={{display: 'flex', alignItems: 'center', gap: '10px', padding: '8px', borderRadius: '8px', transition: 'background 0.15s'}} onMouseEnter={(e) => e.currentTarget.style.background = '#f8fafc'} onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
                    <img src={item.img} alt={item.name} style={{width: '36px', height: '36px', borderRadius: '8px', objectFit: 'contain', background: '#f8fafc'}} />
                    <div style={{flex: 1}}>
                      <div style={{fontSize: '12px', fontWeight: 600, color: '#0f172a'}}>{item.name}</div>
                      <div style={{fontSize: '10px', color: '#94a3b8'}}>{item.category}</div>
                    </div>
                    <span style={{fontSize: '13px', fontWeight: 700, color: '#ef4444'}}>{item.amount}</span>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Most Visited Products */}
            <div className="panel">
              <div className="panel-header">
                <div className="panel-title" style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
                  <i className="ri-eye-line" style={{color: '#3b82f6'}}></i>
                  Most Visited
                </div>
              </div>
              <div style={{display: 'flex', flexDirection: 'column', gap: '6px'}}>
                {[
                  { name: 'Premium Potatoes', category: 'Vegetables', amount: '1,245', img: 'https://i.postimg.cc/d1vdTWyL/1000020583-removebg-preview.png' },
                  { name: 'Sweet Oranges', category: 'Fruits', amount: '1,089', img: 'https://i.postimg.cc/mr7Ckxtx/IMG-20260228-163156.png' },
                  { name: 'Mango Fresh', category: 'Fruits', amount: '956', img: 'https://i.postimg.cc/Z5G6JYKm/IMG-20260228-163217.png' },
                ].map((item, i) => (
                  <div key={i} style={{display: 'flex', alignItems: 'center', gap: '10px', padding: '8px', borderRadius: '8px', transition: 'background 0.15s'}} onMouseEnter={(e) => e.currentTarget.style.background = '#f8fafc'} onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
                    <img src={item.img} alt={item.name} style={{width: '36px', height: '36px', borderRadius: '8px', objectFit: 'contain', background: '#f8fafc'}} />
                    <div style={{flex: 1}}>
                      <div style={{fontSize: '12px', fontWeight: 600, color: '#0f172a'}}>{item.name}</div>
                      <div style={{fontSize: '10px', color: '#94a3b8'}}>{item.category}</div>
                    </div>
                    <span style={{fontSize: '13px', fontWeight: 700, color: '#3b82f6'}}>{item.amount}</span>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Most Added to Cart */}
            <div className="panel">
              <div className="panel-header">
                <div className="panel-title" style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
                  <i className="ri-shopping-cart-2-line" style={{color: '#f59e0b'}}></i>
                  Most in Cart
                </div>
              </div>
              <div style={{display: 'flex', flexDirection: 'column', gap: '6px'}}>
                {[
                  { name: 'Fresh Tomatoes', category: 'Vegetables', amount: '89', img: 'https://i.postimg.cc/mr7CkxtQ/1000020584-removebg-preview.png' },
                  { name: 'Grapes Green', category: 'Fruits', amount: '76', img: 'https://i.postimg.cc/htkVK4PD/IMG-20260228-163208.png' },
                  { name: 'Fresh Broccoli', category: 'Vegetables', amount: '64', img: 'https://i.postimg.cc/qR0nCm36/1000020611-removebg-preview.png' },
                ].map((item, i) => (
                  <div key={i} style={{display: 'flex', alignItems: 'center', gap: '10px', padding: '8px', borderRadius: '8px', transition: 'background 0.15s'}} onMouseEnter={(e) => e.currentTarget.style.background = '#f8fafc'} onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
                    <img src={item.img} alt={item.name} style={{width: '36px', height: '36px', borderRadius: '8px', objectFit: 'contain', background: '#f8fafc'}} />
                    <div style={{flex: 1}}>
                      <div style={{fontSize: '12px', fontWeight: 600, color: '#0f172a'}}>{item.name}</div>
                      <div style={{fontSize: '10px', color: '#94a3b8'}}>{item.category}</div>
                    </div>
                    <span style={{fontSize: '13px', fontWeight: 700, color: '#f59e0b'}}>{item.amount}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>
          
          {/* Store Insights Dashboard */}
          <section style={{display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '24px', marginBottom: '24px'}}>
            {/* Sales Performance Chart */}
            <div className="panel">
              <div className="panel-header"><div className="panel-title">Sales Performance (7 Days)</div></div>
              <div className="chart-area">
                {chartData.map((bar, i) => (
                  <div key={i} className="bar-group">
                    <div className={`bar ${bar.active ? 'active' : ''}`} style={{height: bar.height}}></div>
                    <span className="bar-label">{bar.day}</span>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Revenue Breakdown */}
            <div className="panel">
              <div className="panel-header"><div className="panel-title">Revenue by Category</div></div>
              <div style={{padding: '16px'}}>
                {/* Donut Chart */}
                <div style={{display: 'flex', justifyContent: 'center', marginBottom: '20px'}}>
                  <div style={{width: '140px', height: '140px', position: 'relative'}}>
                    <svg viewBox="0 0 36 36" style={{width: '100%', height: '100%', transform: 'rotate(-90deg)'}}>
                      <circle cx="18" cy="18" r="15.5" fill="none" stroke="#e2e8f0" strokeWidth="4"></circle>
                      <circle cx="18" cy="18" r="15.5" fill="none" stroke="#16a34a" strokeWidth="4" strokeDasharray="35 65" strokeLinecap="round"></circle>
                      <circle cx="18" cy="18" r="15.5" fill="none" stroke="#f59e0b" strokeWidth="4" strokeDasharray="25 75" strokeDashoffset="-35" strokeLinecap="round"></circle>
                      <circle cx="18" cy="18" r="15.5" fill="none" stroke="#ef4444" strokeWidth="4" strokeDasharray="20 80" strokeDashoffset="-60" strokeLinecap="round"></circle>
                      <circle cx="18" cy="18" r="15.5" fill="none" stroke="#3b82f6" strokeWidth="4" strokeDasharray="15 85" strokeDashoffset="-80" strokeLinecap="round"></circle>
                    </svg>
                    <div style={{position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', textAlign: 'center'}}>
                      <div style={{fontSize: '18px', fontWeight: 700, color: '#0f172a'}}>₹1.2L</div>
                      <div style={{fontSize: '10px', color: '#94a3b8'}}>Total</div>
                    </div>
                  </div>
                </div>
                {/* Legend */}
                <div style={{display: 'flex', flexDirection: 'column', gap: '8px'}}>
                  {[
                    { name: 'Vegetables', percent: '35%', amount: '₹42,000', color: '#16a34a' },
                    { name: 'Fruits', percent: '25%', amount: '₹30,000', color: '#f59e0b' },
                    { name: 'Dairy', percent: '20%', amount: '₹24,000', color: '#ef4444' },
                    { name: 'Others', percent: '20%', amount: '₹24,000', color: '#3b82f6' },
                  ].map((item, i) => (
                    <div key={i} style={{display: 'flex', alignItems: 'center', gap: '10px'}}>
                      <div style={{width: '10px', height: '10px', borderRadius: '2px', background: item.color}}></div>
                      <div style={{flex: 1, display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
                        <span style={{fontSize: '12px', color: '#475569'}}>{item.name}</span>
                        <span style={{fontSize: '11px', fontWeight: 600, color: '#0f172a'}}>{item.percent}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>
          
          {/* Key Metrics Cards */}
          <section style={{display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '20px', marginBottom: '24px'}}>
            {[
              { label: 'Total Orders Today', value: '48', change: '+12%', positive: true, icon: 'ri-shopping-bag-line', color: '#16a34a' },
              { label: 'Avg. Order Value', value: '₹856', change: '+8%', positive: true, icon: 'ri-money-dollar-circle-line', color: '#f59e0b' },
              { label: 'New Customers', value: '23', change: '+5%', positive: true, icon: 'ri-user-add-line', color: '#3b82f6' },
              { label: 'Pending Orders', value: '7', change: '-15%', positive: true, icon: 'ri-time-line', color: '#ef4444' },
            ].map((metric, i) => (
              <div key={i} className="panel" style={{padding: '20px'}}>
                <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px'}}>
                  <div style={{width: '40px', height: '40px', borderRadius: '10px', background: `${metric.color}15`, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                    <i className={metric.icon} style={{fontSize: '20px', color: metric.color}}></i>
                  </div>
                  <span style={{fontSize: '11px', fontWeight: 600, color: metric.positive ? '#10b981' : '#ef4444', background: metric.positive ? '#d1fae5' : '#fee2e2', padding: '2px 8px', borderRadius: '12px'}}>{metric.change}</span>
                </div>
                <div style={{fontSize: '22px', fontWeight: 700, color: '#0f172a', marginBottom: '4px'}}>{metric.value}</div>
                <div style={{fontSize: '12px', color: '#94a3b8'}}>{metric.label}</div>
              </div>
            ))}
          </section>
        </>
      )}

      {/* CATEGORY MANAGEMENT VIEW */}
      {dashView === 'categories' && (
        <div className="cat-mgmt-wrapper">
          {editingCategory ? (
            <div className="cat-edit-page">
              <div className="cat-edit-card">
                <div style={{textAlign: 'center', marginBottom: '32px'}}><div style={{fontSize: '22px', fontWeight: 700, fontFamily: "'Plus Jakarta Sans', sans-serif", color: '#1e293b', marginBottom: '6px'}}>{categories.find(c => c.id === editingCategory.id) ? 'Edit Category' : 'Add Category'}</div></div>
                <div className="toggle-container">
                  <div className={`toggle-slider ${editingCategory.type === 'image' ? 'right' : ''}`}></div>
                  <div className={`toggle-btn-switch ${editingCategory.type === 'icon' ? 'active' : ''}`} onClick={() => setEditingCategory({...editingCategory, type: 'icon'})}>Icon Library</div>
                  <div className={`toggle-btn-switch ${editingCategory.type === 'image' ? 'active' : ''}`} onClick={() => setEditingCategory({...editingCategory, type: 'image'})}>Upload Image</div>
                </div>
                <div className="input-group-cat">
                  <label className="input-label-cat">Category Name</label>
                  <input type="text" className="form-input-box" placeholder="e.g., Organic Fruits" value={editingCategory.name} onChange={(e) => setEditingCategory({...editingCategory, name: e.target.value})} />
                </div>
                {editingCategory.type === 'icon' ? (
                  <div className="input-group-cat">
                    <label className="input-label-cat">Icon Code</label>
                    <div className="icon-input-row">
                      <input type="text" className="form-input-box" placeholder="ri-home-line" value={editingCategory.icon} onChange={(e) => setEditingCategory({...editingCategory, icon: e.target.value})} />
                      <div className={`preview-box ${editingCategory.icon && editingCategory.icon.startsWith('ri-') ? 'valid' : (editingCategory.icon ? 'error' : '')}`}>
                        <i className={editingCategory.icon && editingCategory.icon.startsWith('ri-') ? editingCategory.icon : 'ri-cursor-line'}></i>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="input-group-cat">
                    <div className="upload-zone" onClick={() => document.getElementById('catImgUp')?.click()}>
                      <input type="file" id="catImgUp" style={{display: 'none'}} accept="image/*" />
                      {!editingCategory.image ? <p style={{color: '#64748b'}}>Click to upload</p> : <img src={editingCategory.image} style={{width: '64px', height: '64px', objectFit: 'cover', borderRadius: '8px'}} alt="Category preview" />}
                    </div>
                  </div>
                )}
                <div style={{display: 'flex', gap: '12px', marginTop: '32px'}}>
                  <button className="cat-btn-cancel" onClick={() => setEditingCategory(null)}>Cancel</button>
                  <button className="cat-btn-primary" onClick={handleSaveCategory}>Save Changes</button>
                </div>
              </div>
            </div>
          ) : (
            <div className="cat-container">
              <div className="order-card table-header">
                <div className="order-grid-row"><div>Category</div><div>Source</div><div>Products</div><div>Created</div><div>Status</div><div>Manage</div></div>
              </div>
              {categories.map((cat) => (
                <div key={cat.id} className="order-card category-row">
                  <div className="order-grid-row">
                    <div className="category-name-cell">
                      <div style={{width: '36px', height: '36px', border: cat.type === 'icon' ? '1px solid #e2e8f0' : 'none', borderRadius: '6px', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: cat.type === 'image' ? 'hidden' : 'visible'}}>
                        {cat.type === 'icon' ? <i className={cat.icon}></i> : <img src={cat.image} style={{width: '36px', height: '36px', objectFit: 'cover', borderRadius: '6px'}} alt={cat.name} />}
                      </div>
                      <span>{cat.name}</span>
                    </div>
                    <div>{cat.type === 'icon' ? 'Icon Library' : 'Image Upload'}</div>
                    <div>{cat.items} Items</div>
                    <div>{cat.created}</div>
                    <div><span className={`status-bracket ${cat.status === 'Active' ? 'active' : 'hidden-status'}`}>[{cat.status}]</span></div>
                    <div className="manage-col">
                      <i className="ri-pencil-line" onClick={() => openCategoryEdit(cat)}></i>
                      <i className="ri-delete-bin-line" onClick={() => handleDeleteCategory(cat.id)}></i>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* PRODUCT MANAGEMENT VIEW */}
      {dashView === 'products' && (
        <div className="prod-mgmt-wrapper">
          {editingProduct ? (
            <div className="prod-edit-wrapper">
              <div className="max-w-3xl mx-auto" style={{padding: '0 16px'}}>
                <form onSubmit={(e) => { e.preventDefault(); handleSaveProduct(); }}>
                  <div className="ep-card">
                    <h2 style={{fontSize: '16px', fontWeight: 600, marginBottom: '20px'}}>Basic Information</h2>
                    <div style={{marginBottom: '18px'}}>
                      <label style={{display: 'block', fontSize: '13px', fontWeight: 500, marginBottom: '4px'}}>Product Name</label>
                      <input type="text" className="form-input" placeholder="e.g., Organic Red Apples" value={editingProduct.name} onChange={(e) => setEditingProduct({...editingProduct, name: e.target.value})} />
                    </div>
                    <div style={{marginBottom: '18px'}}>
                      <label style={{display: 'block', fontSize: '13px', fontWeight: 500, marginBottom: '4px'}}>Category</label>
                      <select className="form-input" value={editingProduct.category} onChange={(e) => setEditingProduct({...editingProduct, category: e.target.value})}>
                        <option value="">Select Category</option>
                        <option value="Fruits & Vegetables">Fruits & Vegetables</option>
                        <option value="Dairy & Eggs">Dairy & Eggs</option>
                        <option value="Meat & Seafood">Meat & Seafood</option>
                        <option value="Bakery">Bakery</option>
                      </select>
                    </div>
                    <div style={{background: '#f9fafb', borderRadius: '8px', padding: '14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
                      <div><label style={{fontSize: '13px', fontWeight: 500, display: 'block'}}>Offer Product</label><p style={{fontSize: '12px', color: '#64748b'}}>Toggle if this product is currently on sale</p></div>
                      <div className={`switch-lg ${editingProduct.offerSwitch ? 'active' : ''}`} onClick={() => setEditingProduct({...editingProduct, offerSwitch: !editingProduct.offerSwitch})}></div>
                    </div>
                  </div>

                  <div className="ep-card">
                    <h2 style={{fontSize: '16px', fontWeight: 600, marginBottom: '20px'}}>Descriptions</h2>
                    <div style={{marginBottom: '18px'}}>
                      <label style={{display: 'block', fontSize: '13px', fontWeight: 500, marginBottom: '4px'}}>Short Description</label>
                      <input type="text" className="form-input" placeholder="Fresh and organic" value={editingProduct.shortDesc || ''} onChange={(e) => setEditingProduct({...editingProduct, shortDesc: e.target.value})} />
                    </div>
                    <div>
                      <label style={{display: 'block', fontSize: '13px', fontWeight: 500, marginBottom: '4px'}}>Long Description</label>
                      <textarea className="form-input" rows={4} placeholder="Describe the product..." value={editingProduct.longDesc || ''} onChange={(e) => setEditingProduct({...editingProduct, longDesc: e.target.value})}></textarea>
                    </div>
                  </div>

                  <div className="ep-card">
                    <h2 style={{fontSize: '16px', fontWeight: 600, marginBottom: '20px'}}>Product Images</h2>
                    <div className="upload-zone-prod" onClick={() => document.getElementById('prodImgUp')?.click()}>
                      <p style={{color: '#64748b'}}>Click to upload images</p>
                    </div>
                    <div style={{display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px', marginTop: '12px'}}>
                      {prodImages.map((img, i) => <img key={i} src={img} style={{width: '100%', height: '80px', objectFit: 'cover', borderRadius: '8px'}} alt={`Product image ${i+1}`} />)}
                    </div>
                  </div>

                  <div className="ep-card">
                    <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px'}}>
                      <div><h2 style={{fontSize: '16px', fontWeight: 600}}>Varieties & Pricing</h2><p style={{fontSize: '12px', color: '#64748b'}}>Add different sizes or options</p></div>
                      <button type="button" onClick={addVariety} style={{color: '#16a34a', fontWeight: 500, background: 'none', border: 'none', cursor: 'pointer'}}>+ Add Variety</button>
                    </div>
                    {prodVarieties.length === 0 && <div style={{textAlign: 'center', padding: '24px', color: '#64748b', border: '1px dashed #e2e8e0', borderRadius: '8px'}}>No varieties added.</div>}
                    {prodVarieties.map(v => (
                      <div key={v.id} style={{background: '#f9fafb', borderRadius: '8px', padding: '16px', marginBottom: '12px'}}>
                        <div style={{display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px'}}>
                          <input type="number" className="form-input" placeholder="Stock" />
                          <input type="number" className="form-input" placeholder="Price" />
                          <input type="number" className="form-input" placeholder="Discount %" />
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="ep-card">
                    <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px'}}>
                      <div><h2 style={{fontSize: '16px', fontWeight: 600}}>FAQs</h2></div>
                      <button type="button" onClick={addFaq} style={{color: '#16a34a', fontWeight: 500, background: 'none', border: 'none', cursor: 'pointer'}}>+ Add FAQ</button>
                    </div>
                    {prodFaqs.length === 0 && <div style={{textAlign: 'center', padding: '24px', color: '#64748b', border: '1px dashed #e2e8e0', borderRadius: '8px'}}>No FAQs added.</div>}
                    {prodFaqs.map(f => (
                      <div key={f.id} style={{background: '#f9fafb', borderRadius: '8px', padding: '16px', marginBottom: '12px'}}>
                        <input type="text" className="form-input" placeholder="Question" style={{marginBottom: '8px'}} />
                        <textarea className="form-input" rows={2} placeholder="Answer"></textarea>
                      </div>
                    ))}
                  </div>

                  <div className="ep-card">
                    <label style={{display: 'block', fontSize: '13px', fontWeight: 500, marginBottom: '4px'}}>Related Products</label>
                    <div style={{display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px', marginTop: '12px'}}>
                      {allRelatedOptions.map(p => (
                        <div key={p.id} className={`related-product-card ${prodRelated.includes(p.id) ? 'selected' : ''}`} onClick={() => toggleRelated(p.id)}>
                          <img src={p.image} alt={p.name} />
                          <div style={{flex: 1}}><p style={{fontSize: '12px', fontWeight: 600}}>{p.name}</p><span style={{fontSize: '11px', color: '#16a34a'}}>${p.price}</span></div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div style={{display: 'flex', gap: '12px', marginTop: '8px', marginBottom: '40px'}}>
                    <button type="button" className="btn-cancel-prod" style={{flex: 1}} onClick={() => setEditingProduct(null)}>Cancel</button>
                    <button type="submit" className="btn-primary-prod" style={{flex: 1}}>Save Changes</button>
                  </div>
                </form>
              </div>
            </div>
          ) : (
            <div className="prod-container">
              <div style={{marginBottom: '20px', fontSize: '18px', fontWeight: 700, fontFamily: "'Plus Jakarta Sans'"}}>Product Management</div>
              <div className="prod-table-header">
                <div className="prod-grid-row">
                  <div>Product Details</div><div>Variants</div><div>Price Range</div><div>Discount</div><div>Offer</div><div>Status</div><div style={{textAlign: 'right'}}>Action</div>
                </div>
              </div>
              {products.map((prod) => (
                <div key={prod.id} className="prod-order-card product-row">
                  <div className="prod-grid-row">
                    <div className="product-cell">
                      <img src={prod.image} alt={prod.name} />
                      <div className="product-info"><span className="product-name">{prod.name}</span><span className="product-cat">{prod.category}</span></div>
                    </div>
                    <div>{prod.variants}</div>
                    <div>{prod.price}</div>
                    <div className="bracket-text text-red">[{prod.discount}]</div>
                    <div className={`bracket-text ${prod.offer ? 'text-blue' : 'text-muted-val'}`}>[{prod.offer ? 'Yes' : 'No'}]</div>
                    <div><div className={`switch-sm ${prod.status === 'active' ? 'active' : ''}`} onClick={() => toggleProdStatus(prod.id)}></div></div>
                    <div className="prod-manage-col">
                      <i className="ri-pencil-line" onClick={() => openProductEdit(prod)}></i>
                      <i className="ri-delete-bin-line" onClick={() => setProducts(products.filter(p => p.id !== prod.id))}></i>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ORDER MANAGEMENT VIEW */}
      {dashView === 'orders' && (
        <div className="p-4 md:p-8" style={{fontFamily: "'Inter', sans-serif", backgroundColor: '#eef0f4', color: '#1c2333', margin: '0', minHeight: 'calc(100vh - 80px)'}}>
          {/* Header */}
          <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-2xl font-bold text-[#1c2333] tracking-tight">Order Management</h1>
              <p className="text-[#8a96a8] text-sm mt-1">Detailed overview of all incoming requests</p>
            </div>
            <div className="flex items-center gap-4">
              <span className="px-4 py-1.5 bg-[#3f72f5]/10 text-[#3f72f5] text-[13px] font-bold uppercase tracking-wider rounded-lg">
                {orders.filter(o => o.status === 'pending').length} Pending
              </span>
            </div>
          </div>

          {/* Filter Tabs */}
          <div className="mb-4 flex items-center gap-2 flex-wrap">
            <button onClick={() => setCurrentOrderFilter('all')} 
              className={`px-4 py-2 text-[13px] font-semibold rounded-lg border border-[#e4e7ee] transition-colors ${currentOrderFilter === 'all' ? 'bg-[#1c2333] text-white' : 'bg-white text-[#8a96a8] hover:bg-[#f5f6f9]'}`}>
              All Orders
            </button>
            <button onClick={() => setCurrentOrderFilter('pending')} 
              className={`px-4 py-2 text-[13px] font-semibold rounded-lg border border-[#e4e7ee] transition-colors ${currentOrderFilter === 'pending' ? 'bg-[#f59e0b] text-white' : 'bg-white text-[#8a96a8] hover:bg-[#f5f6f9]'}`}>
              Pending
            </button>
            <button onClick={() => setCurrentOrderFilter('approved')} 
              className={`px-4 py-2 text-[13px] font-semibold rounded-lg border border-[#e4e7ee] transition-colors ${currentOrderFilter === 'approved' ? 'bg-[#18a87a] text-white' : 'bg-white text-[#8a96a8] hover:bg-[#f5f6f9]'}`}>
              Approved
            </button>
            <button onClick={() => setCurrentOrderFilter('canceled')} 
              className={`px-4 py-2 text-[13px] font-semibold rounded-lg border border-[#e4e7ee] transition-colors ${currentOrderFilter === 'canceled' ? 'bg-[#ef4444] text-white' : 'bg-white text-[#8a96a8] hover:bg-[#f5f6f9]'}`}>
              Canceled
            </button>
          </div>

          {/* Main Table Card */}
          <div className="bg-white border border-[#e4e7ee] rounded-xl shadow-sm overflow-hidden">
            <div className="p-4 border-b border-[#e4e7ee] flex items-center justify-between">
              <h3 className="text-base font-semibold text-[#1c2333]">Orders List</h3>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-[13px]">
                <thead className="bg-[#f5f6f9] border-b border-[#e4e7ee]">
                  <tr>
                    <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase tracking-wider w-1/6">Order Details</th>
                    <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase tracking-wider w-1/6">Customer</th>
                    <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase tracking-wider w-1/6">Payment Info</th>
                    <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase tracking-wider w-1/6">Status</th>
                    <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase tracking-wider w-1/6">Courier Status</th>
                    <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase tracking-wider w-1/6">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#e4e7ee]">
                  {filteredOrders.map((order) => (
                    <tr key={order.id} className="hover:bg-[#f5f6f9]/50 transition-colors group">
                      {/* Col 1: Order Details */}
                      <td className="px-4 py-3 align-middle">
                        <span className="font-mono text-sm font-medium text-[#1c2333]">{order.id}</span>
                        <div className="text-[11px] text-[#8a96a8] mt-0.5">{order.time}</div>
                      </td>
                      
                      {/* Col 2: Customer */}
                      <td className="px-4 py-3 align-middle">
                        <div className="flex flex-col">
                          <span className="font-medium text-[#1c2333]">{order.customer}</span>
                          <span className="text-[11px] text-[#8a96a8]">{order.phone}</span>
                        </div>
                      </td>

                      {/* Col 3: Payment & Address */}
                      <td className="px-4 py-3 align-middle">
                        <div className="flex flex-col gap-1">
                          <span className="text-[11px] font-bold text-[#1c2333] uppercase tracking-wide">{order.paymentMethod}</span>
                          <span className="text-[11px] text-[#8a96a8] truncate max-w-[150px]">{order.address}</span>
                        </div>
                      </td>

                      {/* Col 4: Status */}
                      <td className="px-4 py-3 align-middle" onClick={(e) => e.stopPropagation()}>
                        <div className="flex flex-col gap-0.5">
                          {order.status === 'pending' && (
                            <div className="flex items-center gap-2">
                              <span onClick={() => updateOrderStatus(order.id, 'approved')} className="text-[#18a87a] font-bold text-[11px] cursor-pointer hover:underline">Approve</span>
                              <span className="text-[#8a96a8] text-[10px]">|</span>
                              <span onClick={() => updateOrderStatus(order.id, 'canceled')} className="text-[#ef4444] font-bold text-[11px] cursor-pointer hover:underline">Reject</span>
                            </div>
                          )}
                          {order.status === 'approved' && (
                            <div className="flex flex-col">
                              <span className="text-[#18a87a] font-bold text-[11px]">Approved</span>
                              <span className="text-[10px] text-[#8a96a8]">by Admin</span>
                            </div>
                          )}
                          {order.status === 'canceled' && (
                            <div className="flex flex-col">
                              <span className="text-[#ef4444] font-bold text-[11px]">Canceled</span>
                              <span className="text-[10px] text-[#8a96a8]">by {order.canceledBy || 'System'}</span>
                            </div>
                          )}
                        </div>
                      </td>

                      {/* Col 5: Courier Status */}
                      <td className="px-4 py-3 align-middle text-left">
                        <span className="text-[11px] font-medium text-[#8a96a8]">[{order.courierStatus}]</span>
                      </td>

                      {/* Col 6: Actions */}
                      <td className="px-4 py-3 align-middle text-left">
                        <span onClick={() => setSelectedOrder(order)} 
                          className="text-[13px] font-medium text-[#8a96a8] hover:text-[#3f72f5] cursor-pointer transition-colors">
                          View
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Order Detail Modal */}
          {selectedOrder && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1c2333]/40 backdrop-blur-sm" onClick={() => setSelectedOrder(null)}>
              <div className="bg-white w-full max-w-[680px] border border-[#e4e7ee] flex flex-col p-6 gap-3 rounded-xl shadow-2xl" onClick={(e) => e.stopPropagation()}>
                {/* Header Section */}
                <div className="flex justify-between items-start">
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm font-bold text-[#1c2333] uppercase">{selectedOrder.id}</span>
                      <span className="text-[#e4e7ee]">|</span>
                      <span className="text-[12px] text-[#8a96a8]">{selectedOrder.date}</span>
                    </div>
                    <div className="text-[11px] font-bold text-[#1c2333] uppercase tracking-wide">
                      {selectedOrder.paymentMethod}
                    </div>
                    <div className="text-[11px] text-[#8a96a8] flex items-center gap-1 max-w-[350px]">
                      <i className="ri-map-pin-line text-[12px] shrink-0"></i>
                      <span className="truncate">{selectedOrder.address}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button onClick={() => window.open('tel:' + selectedOrder.phone)} title="Call" 
                      className="h-[28px] w-[28px] rounded-md flex items-center justify-center text-[#8a96a8] hover:text-[#3f72f5] transition-colors bg-white border border-[#e4e7ee] shadow-sm">
                      <i className="ri-phone-fill text-[16px]"></i>
                    </button>
                    <button onClick={() => window.open('https://wa.me/' + selectedOrder.phone.replace(/[^0-9]/g, ''))} title="WhatsApp" 
                      className="h-[28px] w-[28px] rounded-md flex items-center justify-center text-[#8a96a8] hover:text-[#18a87a] transition-colors bg-white border border-[#e4e7ee] shadow-sm">
                      <i className="ri-whatsapp-line text-[16px]"></i>
                    </button>
                    <button onClick={() => copyToClipboard(selectedOrder.phone)} title="Copy" 
                      className="h-[28px] w-[28px] rounded-md flex items-center justify-center text-[#8a96a8] hover:text-[#1c2333] transition-colors bg-white border border-[#e4e7ee] shadow-sm">
                      <i className="ri-file-copy-line text-[16px]"></i>
                    </button>

                    <div className="h-[20px] w-[1px] bg-[#e4e7ee] mx-1"></div>

                    <button onClick={() => setSelectedOrder(null)} className="w-[30px] h-[30px] rounded-lg bg-white border border-[#e4e7ee] flex items-center justify-center text-[#8a96a8] hover:bg-[#f5f6f9] cursor-pointer transition-colors">
                      <i className="ri-close-line text-[18px]"></i>
                    </button>
                  </div>
                </div>

                {/* Items Table */}
                <div className="w-full border-collapse bg-[#f5f6f9] rounded-lg overflow-hidden">
                  <table className="w-full text-[13px]">
                    <thead>
                      <tr className="border-b border-[#e4e7ee]">
                        <th className="py-2 px-3 text-left text-[11px] font-bold uppercase text-[#8a96a8] tracking-wide w-[50%]">Item</th>
                        <th className="py-2 px-3 text-center text-[11px] font-bold uppercase text-[#8a96a8] tracking-wide w-[20%]">Qty</th>
                        <th className="py-2 px-3 text-right text-[11px] font-bold uppercase text-[#8a96a8] tracking-wide w-[30%]">Price</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedOrder.items.map((item, idx) => (
                        <tr key={idx} className="border-b border-[#e4e7ee] last:border-0">
                          <td className="py-2 px-3 align-middle">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-semibold text-[#1c2333]">{item.name}</span>
                              {item.variant && <span className="text-[#8a96a8] text-[12px] font-medium">({item.variant})</span>}
                              {item.offerText && <span className="text-[#ef4444] text-[11px] font-bold">[{item.offerText}]</span>}
                              {item.couponCode && <span className="text-[#18a87a] text-[11px] font-bold">[{item.couponCode}]</span>}
                            </div>
                          </td>

                          <td className="py-2 px-3 text-center align-middle font-medium text-[#1c2333]">
                            <div className="flex flex-col items-center">
                              <span>{item.qty} item{item.qty > 1 ? 's' : ''}</span>
                              <span className="text-[11px] font-medium text-[#8a96a8]">TK {item.basePrice}/pc</span>
                            </div>
                          </td>

                          <td className="py-2 px-3 text-right align-middle">
                            <div className="flex flex-col items-end gap-0.5">
                              <div className={`text-[#8a96a8] text-[12px] ${item.offerDiscount > 0 || item.couponDiscount > 0 ? 'line-through decoration-[#ef4444]/30' : ''}`}>
                                TK {item.basePrice * item.qty}
                              </div>

                              {item.offerDiscount > 0 && (
                                <div className="text-[#ef4444] text-[11px] font-medium">
                                  -TK {item.offerDiscount * item.qty}
                                </div>
                              )}

                              {item.couponDiscount > 0 && (
                                <div className="text-[#18a87a] text-[11px] font-medium">
                                  -TK {item.couponDiscount * item.qty}
                                </div>
                              )}

                              <div className="font-bold text-[#1c2333] text-[13px]">
                                TK {(item.basePrice * item.qty) - (item.offerDiscount * item.qty) - (item.couponDiscount * item.qty)}
                              </div>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Calculation */}
                <div className="bg-[#f5f6f9] rounded-lg p-3">
                  <div className="flex items-center justify-between text-[12px] w-full flex-wrap gap-2">
                    <div className="font-semibold text-[#8a96a8] italic" 
                         style={{visibility: selectedOrder.discount === 0 && (!selectedOrder.couponCodes || selectedOrder.couponCodes.length === 0) ? 'visible' : 'hidden'}}>
                      Order Calculation
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      <div className="flex items-center gap-1">
                        <span className="font-medium text-[#8a96a8]">Subtotal :</span>
                        <span className="font-bold text-[#1c2333]">TK {selectedOrder.subtotal}</span>
                      </div>

                      <div className="w-[1px] h-3 bg-[#e4e7ee]"></div>

                      {selectedOrder.discount > 0 && (
                        <>
                          <div className="flex items-center gap-1 text-[#ef4444]">
                            <span className="font-medium">Discount :</span>
                            <span className="font-bold">TK {selectedOrder.discount}</span>
                          </div>
                          <div className="w-[1px] h-3 bg-[#e4e7ee]"></div>
                        </>
                      )}

                      {selectedOrder.couponCodes && selectedOrder.couponCodes.length > 0 && (
                        <>
                          <div className="flex items-center gap-1 text-[#18a87a]">
                            <span className="font-medium">Coupon :</span>
                            <span className="font-bold">TK {selectedOrder.couponAmount}</span>
                          </div>
                          <div className="w-[1px] h-3 bg-[#e4e7ee]"></div>
                        </>
                      )}

                      <div className="flex items-center gap-1">
                        <span className="font-medium text-[#8a96a8]">Delivery :</span>
                        <span className="font-bold text-[#1c2333]">{selectedOrder.delivery === 0 ? 'Free' : 'TK ' + selectedOrder.delivery}</span>
                      </div>

                      <div className="w-[1px] h-3 bg-[#e4e7ee] mx-1"></div>

                      <div className="flex items-center gap-1">
                        <span className="font-bold text-[#8a96a8] uppercase tracking-wide">Total :</span>
                        <span className="font-extrabold text-[#1c2333]">TK {selectedOrder.total}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* COUPON MANAGEMENT VIEW */}
      {dashView === 'coupons' && (
        <div className="p-4 md:p-8" style={{fontFamily: "'IBM Plex Sans', sans-serif", backgroundColor: '#f4f7fa', color: '#1e293b', margin: '0', minHeight: 'calc(100vh - 80px)'}}>
          {editingCoupon ? (
            <div className="max-w-[560px] mx-auto px-6">
              {/* Back Header */}
              <div className="flex items-center gap-3 mb-6">
                <button onClick={() => setEditingCoupon(null)} className="bg-none border-none cursor-pointer p-0 flex items-center">
                  <i className="ri-arrow-left-line text-xl text-[#64748b]"></i>
                </button>
                <div>
                  <div className="text-lg font-bold font-sans">{editingCoupon.id ? 'Edit Coupon' : 'Add Coupon'}</div>
                  <div className="text-xs text-[#94a3b8] mt-0.5">Configure your discount coupon</div>
                </div>
              </div>

              <form onSubmit={(e) => { e.preventDefault(); handleSaveCoupon(); }}>
                {/* Coupon Details Card */}
                <div className="bg-white border border-[#e2e8e0] rounded-xl p-6 mb-4">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-[#64748b] mb-4">Coupon Details</div>

                  <div className="mb-4">
                    <label className="block text-xs font-medium text-[#64748b] mb-1.5">Coupon Code</label>
                    <input type="text" 
                      className="w-full px-3.5 py-2.5 bg-white border border-[#e2e8e0] rounded-lg text-sm outline-none focus:border-[#16a34a] transition-colors"
                      style={{textTransform: 'uppercase', letterSpacing: '0.6px'}}
                      placeholder="e.g., SUMMER20"
                      value={couponForm.code}
                      onChange={(e) => setCouponForm({...couponForm, code: e.target.value.toUpperCase()})} />
                  </div>

                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div>
                      <label className="block text-xs font-medium text-[#64748b] mb-1.5">Coupon Type</label>
                      <div className="relative">
                        <select 
                          className="w-full px-3.5 py-2.5 bg-white border border-[#e2e8e0] rounded-lg text-sm outline-none appearance-none cursor-pointer focus:border-[#16a34a] transition-colors"
                          value={couponForm.type}
                          onChange={(e) => setCouponForm({...couponForm, type: e.target.value as 'pct' | 'fixed'})}>
                          <option value="pct">% Percentage Off</option>
                          <option value="fixed">$ Fixed Amount Off</option>
                        </select>
                        <i className="ri-arrow-down-s-line absolute right-3 top-1/2 -translate-y-1/2 text-[#94a3b8] pointer-events-none"></i>
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-[#64748b] mb-1.5">
                        {couponForm.type === 'pct' ? 'Discount Percentage' : 'Discount Amount'}
                      </label>
                      <div className="relative">
                        <span className={`absolute left-3 top-1/2 -translate-y-1/2 font-bold text-sm ${couponForm.type === 'pct' ? 'text-[#d97706]' : 'text-[#2563eb]'}`}>
                          {couponForm.type === 'pct' ? '%' : '$'}
                        </span>
                        <input type="number" 
                          className="w-full px-3.5 py-2.5 pl-7 bg-white border border-[#e2e8e0] rounded-lg text-sm outline-none focus:border-[#16a34a] transition-colors"
                          placeholder={couponForm.type === 'pct' ? '20' : '15'}
                          value={couponForm.value}
                          onChange={(e) => setCouponForm({...couponForm, value: e.target.value})}
                          min="1" />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#64748b] mb-1.5">
                      Expiry Date <span className="text-[#cbd5e1] text-[11px] font-normal ml-1">(optional)</span>
                    </label>
                    <input type="date" 
                      className="w-full px-3.5 py-2.5 bg-white border border-[#e2e8e0] rounded-lg text-sm outline-none focus:border-[#16a34a] transition-colors"
                      value={couponForm.expiry}
                      onChange={(e) => setCouponForm({...couponForm, expiry: e.target.value})} />
                  </div>
                </div>

                {/* Applies To Card */}
                <div className="bg-white border border-[#e2e8e0] rounded-xl p-6 mb-4">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-[#64748b] mb-4">Applies To</div>

                  <div className="mb-4">
                    <label className="block text-xs font-medium text-[#64748b] mb-1.5">Scope</label>
                    <div className="relative">
                      <select 
                        className="w-full px-3.5 py-2.5 bg-white border border-[#e2e8e0] rounded-lg text-sm outline-none appearance-none cursor-pointer focus:border-[#16a34a] transition-colors"
                        value={couponForm.scope}
                        onChange={(e) => setCouponForm({...couponForm, scope: e.target.value as 'all' | 'products' | 'categories'})}>
                        <option value="all">All Products</option>
                        <option value="products">Specific Products</option>
                        <option value="categories">Specific Categories</option>
                      </select>
                      <i className="ri-arrow-down-s-line absolute right-3 top-1/2 -translate-y-1/2 text-[#94a3b8] pointer-events-none"></i>
                    </div>
                  </div>

                  {/* Product Picker */}
                  {couponForm.scope === 'products' && (
                    <div className="pt-4 border-t border-[#f1f5f9]">
                      <div className="text-[11px] font-bold uppercase tracking-wider text-[#94a3b8] mb-3">Select Products</div>
                      <div className="grid grid-cols-2 gap-2">
                        {couponProducts.map(p => (
                          <div key={p.id} 
                            className={`flex items-center gap-2.5 p-2.5 border-[1.5px] rounded-lg cursor-pointer transition-all ${pickedProducts.includes(p.id) ? 'border-[#16a34a] bg-[#f0fdf4]' : 'border-[#e2e8e0] bg-white hover:border-[#94a3b8]'}`}
                            onClick={() => toggleProductPick(p.id)}>
                            <img src={p.img} alt={p.name} className="w-9 h-9 rounded-md object-cover flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                              <div className="text-xs font-semibold truncate">{p.name}</div>
                              <div className="text-[11px] text-[#16a34a] font-semibold">{p.price}</div>
                            </div>
                            <div className={`w-4 h-4 rounded flex items-center justify-center flex-shrink-0 ${pickedProducts.includes(p.id) ? 'bg-[#16a34a] border-[#16a34a]' : 'border-[1.5px] border-[#cbd5e1]'}`}>
                              {pickedProducts.includes(p.id) && <span className="text-white text-[10px]">✓</span>}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Category Picker */}
                  {couponForm.scope === 'categories' && (
                    <div className="pt-4 border-t border-[#f1f5f9]">
                      <div className="text-[11px] font-bold uppercase tracking-wider text-[#94a3b8] mb-3">Select Categories</div>
                      <div className="flex flex-wrap gap-2">
                        {couponCategories.map(cat => (
                          <div key={cat.name}
                            className={`inline-flex items-center gap-1.5 px-4 py-2 border-[1.5px] rounded-lg cursor-pointer text-xs font-medium transition-all ${pickedCategories.includes(cat.name) ? 'border-[#16a34a] bg-[#f0fdf4]' : 'border-[#e2e8e0] bg-white hover:border-[#94a3b8]'}`}
                            onClick={() => toggleCategoryPick(cat.name)}>
                            <span className="w-2 h-2 rounded-full flex-shrink-0" style={{background: cat.color}}></span>
                            <span className={pickedCategories.includes(cat.name) ? 'text-[#16a34a]' : ''}>{cat.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Buttons */}
                <div className="flex gap-3 mt-1">
                  <button type="button" onClick={() => setEditingCoupon(null)} className="flex-1 py-3 bg-white text-[#64748b] border-[1.5px] border-[#e2e8e0] rounded-lg text-sm font-medium hover:bg-[#f8faf8] transition-all">Cancel</button>
                  <button type="submit" className="flex-1 py-3 bg-[#16a34a] text-white border-none rounded-lg text-sm font-semibold hover:bg-[#15803d] transition-all">Save Coupon</button>
                </div>
              </form>
            </div>
          ) : (
            <div className="max-w-full px-0">
              {/* Page Header */}
              <div className="flex justify-between items-center mb-7">
                <div className="text-lg font-bold font-sans">Coupon Management</div>
                <button onClick={() => openCouponEdit()} className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-[#16a34a] text-white border-none rounded-lg text-[13px] font-semibold cursor-pointer hover:bg-[#15803d] transition-colors">
                  <i className="ri-add-line text-base"></i>
                  Add Coupon
                </button>
              </div>

              {/* Table */}
              <div className="flex flex-col gap-2">
                {/* Header Row */}
                <div className="grid grid-cols-6 pb-3 border-b border-[#f1f5f9] mb-1">
                  <div className="px-6 text-[11px] font-bold uppercase tracking-wider text-[#64748b]">Code</div>
                  <div className="px-6 text-[11px] font-bold uppercase tracking-wider text-[#64748b]">Type</div>
                  <div className="px-6 text-[11px] font-bold uppercase tracking-wider text-[#64748b]">Discount</div>
                  <div className="px-6 text-[11px] font-bold uppercase tracking-wider text-[#64748b]">Applies To</div>
                  <div className="px-6 text-[11px] font-bold uppercase tracking-wider text-[#64748b] text-right">Expiry</div>
                  <div className="px-6 text-[11px] font-bold uppercase tracking-wider text-[#64748b] text-right">Action</div>
                </div>

                {/* Data Rows */}
                {coupons.map((coupon) => (
                  <div key={coupon.id} className="grid grid-cols-6 bg-white rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.04),0_0_0_1px_#f1f5f9] overflow-hidden hover:shadow-[0_4px_12px_rgba(0,0,0,0.07),0_0_0_1px_#e2e8f0] transition-shadow">
                    <div className="px-6 py-5 border-r border-[#eef2f6] flex items-center">
                      <span className="text-[13px] font-bold tracking-[0.7px] truncate">{coupon.code}</span>
                    </div>
                    <div className="px-6 py-5 border-r border-[#eef2f6] flex items-center">
                      <span className={`text-[13px] font-medium ${coupon.type === 'pct' ? 'text-[#d97706]' : 'text-[#2563eb]'}`}>
                        [{coupon.type === 'pct' ? '% Percentage' : '$ Fixed'}]
                      </span>
                    </div>
                    <div className="px-6 py-5 border-r border-[#eef2f6] flex items-center">
                      <span className={`text-[13px] font-medium ${coupon.type === 'pct' ? 'text-[#d97706]' : 'text-[#2563eb]'}`}>
                        [{coupon.type === 'pct' ? `${coupon.value}% Off` : `$${coupon.value} Off`}]
                      </span>
                    </div>
                    <div className="px-6 py-5 border-r border-[#eef2f6] flex items-center">
                      <span className={`text-[13px] font-medium ${coupon.scope === 'all' ? 'text-[#16a34a]' : 'text-[#2563eb]'}`}>
                        [{coupon.scope === 'all' ? 'All Products' : coupon.scope === 'products' ? 'Specific Products' : 'Specific Categories'}]
                      </span>
                    </div>
                    <div className="px-6 py-5 border-r border-[#eef2f6] flex items-center justify-end">
                      <span className="text-[13px] font-medium text-[#94a3b8]">{formatExpiry(coupon.expiry)}</span>
                    </div>
                    <div className="px-6 py-5 flex items-center justify-end">
                      <div className="flex gap-3.5">
                        <i className="ri-pencil-line text-[17px] text-[#94a3b8] cursor-pointer hover:text-[#1e293b] transition-colors" onClick={() => openCouponEdit(coupon)}></i>
                        <i className="ri-delete-bin-line text-[17px] text-[#94a3b8] cursor-pointer hover:text-[#ef4444] transition-colors" onClick={() => deleteCoupon(coupon.id)}></i>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ABANDONED CHECKOUTS VIEW */}
      {dashView === 'abandoned' && (
        <div className="p-4 md:p-8" style={{fontFamily: "'Inter', sans-serif", backgroundColor: '#f8fafc', color: '#0f172a', margin: '0', minHeight: 'calc(100vh - 80px)'}}>
          {/* Card */}
          <div style={{background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '12px', overflow: 'hidden', boxShadow: '0 1px 3px rgba(0,0,0,0.05)'}}>
            {/* Card Header */}
            <div style={{padding: '1.1rem 1.4rem', borderBottom: '1px solid #e2e8f0', display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
              <div>
                <div style={{fontSize: '1rem', fontWeight: 600, color: '#0f172a'}}>Abandoned Checkouts</div>
                <div style={{fontSize: '0.76rem', color: '#64748b', marginTop: '2px'}}>Customers who visited but didn't complete checkout</div>
              </div>
              <span style={{
                display: 'inline-flex', alignItems: 'center', gap: '0.18rem',
                padding: '0.3rem 0.7rem', fontSize: '0.7rem', fontWeight: 600,
                borderRadius: '20px', textTransform: 'uppercase', letterSpacing: '0.04em',
                background: '#fef3c7', color: '#d97706'
              }}>
                <i className="ri-error-warning-line"></i> {abandonedCheckouts.length} Active
              </span>
            </div>
            
            {/* Table */}
            <div style={{overflowX: 'auto'}}>
              <table style={{width: '100%', borderCollapse: 'collapse'}}>
                <thead>
                  <tr>
                    <th style={{width: '25%', textAlign: 'left', padding: '0.75rem 1.2rem', fontSize: '0.7rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#64748b', background: '#f8fafc', borderBottom: '1px solid #e2e8f0'}}>Customer</th>
                    <th style={{width: '30%', textAlign: 'left', padding: '0.75rem 1.2rem', fontSize: '0.7rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#64748b', background: '#f8fafc', borderBottom: '1px solid #e2e8f0'}}>Address</th>
                    <th style={{width: '25%', textAlign: 'left', padding: '0.75rem 1.2rem', fontSize: '0.7rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#64748b', background: '#f8fafc', borderBottom: '1px solid #e2e8f0'}}>Last Visit</th>
                    <th style={{width: '20%', textAlign: 'left', padding: '0.75rem 1.2rem', fontSize: '0.7rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#64748b', background: '#f8fafc', borderBottom: '1px solid #e2e8f0'}}>Visits</th>
                  </tr>
                </thead>
                <tbody>
                  {abandonedCheckouts.map((ab) => (
                    <React.Fragment key={ab.id}>
                      {/* Main Row */}
                      <tr 
                        style={{cursor: 'pointer', transition: 'background 0.15s'}}
                        onClick={() => toggleAbandonedExpand(ab.id)}
                        onMouseEnter={(e) => e.currentTarget.querySelectorAll('td').forEach(td => td.style.background = '#f8fafc')}
                        onMouseLeave={(e) => e.currentTarget.querySelectorAll('td').forEach(td => td.style.background = 'transparent')}>
                        <td style={{padding: '0.9rem 1.2rem', fontSize: '0.85rem', borderBottom: '1px solid #e2e8f0', verticalAlign: 'middle'}}>
                          <div style={{display: 'flex', alignItems: 'center', gap: '0.7rem'}}>
                            <div style={{
                              width: '34px', height: '34px', borderRadius: '50%', flexShrink: 0,
                              background: '#d1fae5', border: '1.5px solid #16a34a',
                              display: 'flex', alignItems: 'center', justifyContent: 'center',
                              fontWeight: 700, fontSize: '0.75rem', color: '#16a34a'
                            }}>{getInitials(ab.name)}</div>
                            <div>
                              <div style={{fontWeight: 600, fontSize: '0.875rem', color: '#0f172a'}}>{ab.name}</div>
                              <div style={{fontSize: '0.72rem', color: '#64748b', marginTop: '2px'}}>{ab.phone}</div>
                            </div>
                          </div>
                        </td>
                        <td style={{padding: '0.9rem 1.2rem', fontSize: '0.83rem', borderBottom: '1px solid #e2e8f0', verticalAlign: 'middle', color: '#475569'}}>{ab.address}</td>
                        <td style={{padding: '0.9rem 1.2rem', fontSize: '0.85rem', borderBottom: '1px solid #e2e8f0', verticalAlign: 'middle'}}>
                          <div style={{fontWeight: 500, fontSize: '0.83rem', color: '#0f172a'}}>{ab.visitTime}</div>
                          <div style={{fontSize: '0.71rem', color: '#64748b', marginTop: '2px'}}>{ab.visitDate}</div>
                        </td>
                        <td style={{padding: '0.9rem 1.2rem', fontSize: '0.85rem', borderBottom: '1px solid #e2e8f0', verticalAlign: 'middle'}}>
                          <div style={{display: 'inline-flex', alignItems: 'center', gap: '1.5rem'}}>
                            <div style={{display: 'flex', alignItems: 'center', gap: '0.4rem'}}>
                              <span style={{fontWeight: 600, fontSize: '0.83rem', color: '#0f172a'}}>{ab.totalVisits}</span>
                              <span style={{fontSize: '0.71rem', color: '#64748b'}}>visits</span>
                              <span style={{width: '1px', height: '10px', background: '#cbd5e1', display: 'inline-block', margin: '0 0.12rem'}}></span>
                              <span style={{fontWeight: 600, fontSize: '0.83rem', color: '#16a34a'}}>{ab.completedOrders}</span>
                              <span style={{fontSize: '0.71rem', color: '#64748b'}}>done</span>
                            </div>
                            <i className="ri-arrow-down-s-line" style={{
                              transition: 'transform 0.25s ease', fontSize: '1.2rem', color: '#64748b',
                              transform: expandedAbandoned === ab.id ? 'rotate(180deg)' : 'rotate(0deg)'
                            }}></i>
                          </div>
                        </td>
                      </tr>
                      
                      {/* Expand Row */}
                      {expandedAbandoned === ab.id && (
                        <tr>
                          <td colSpan={4} style={{padding: 0, background: '#ffffff', borderBottom: '1px solid #e2e8f0'}}>
                            <div style={{padding: '1.2rem 1.4rem'}}>
                              <table style={{width: '100%', borderCollapse: 'collapse'}}>
                                <tbody>
                                  {ab.history.map((h, idx) => {
                                    const isComp = h.status === 'completed'
                                    const priceColor = isComp ? '#16a34a' : '#ef4444'
                                    const entries = buildEntries(h.products)
                                    const totalItems = entries.reduce((acc, e) => acc + e.qty, 0)
                                    
                                    return (
                                      <tr key={idx} style={{cursor: 'pointer'}} onMouseEnter={(e) => e.currentTarget.querySelectorAll('td').forEach(td => td.style.background = '#f8fafc')}>
                                        <td style={{width: '20%', whiteSpace: 'nowrap', padding: '0.95rem 1rem', fontSize: '0.82rem', borderBottom: idx === ab.history.length - 1 ? 'none' : '1px solid #e2e8f0', verticalAlign: 'middle'}}>
                                          <div style={{fontSize: '0.82rem', fontWeight: 600, color: '#0f172a'}}>{h.date}</div>
                                          <div style={{fontSize: '0.7rem', color: '#64748b', marginTop: '3px'}}>{h.time} · {h.timeAgo}</div>
                                        </td>
                                        <td style={{padding: '0.95rem 1rem', fontSize: '0.82rem', borderBottom: idx === ab.history.length - 1 ? 'none' : '1px solid #e2e8f0', verticalAlign: 'middle'}}>
                                          <div style={{display: 'flex', flexWrap: 'wrap', alignItems: 'baseline', gap: 0, lineHeight: 1.6}}>
                                            {entries.map((e, i) => {
                                              const isLast = i === entries.length - 1
                                              const variantText = e.variant ? ` (${e.variant})` : ''
                                              return (
                                                <span key={i} style={{display: 'inline-flex', alignItems: 'baseline', gap: 0, fontSize: '0.81rem', color: '#475569'}}>
                                                  <span style={{color: '#0f172a', fontWeight: 500}}>{e.name}</span>
                                                  {e.variant && <span style={{color: '#64748b', fontSize: '0.75rem'}}>{variantText}</span>}
                                                  <span style={{color: '#16a34a', fontWeight: 700, fontSize: '0.75rem', marginLeft: '0.15rem'}}> ×{e.qty}</span>
                                                  {!isLast && <span style={{color: '#cbd5e1', margin: '0 0.6rem', fontSize: '0.8rem', opacity: 0.6}}>|</span>}
                                                </span>
                                              )
                                            })}
                                          </div>
                                        </td>
                                        <td style={{width: '15%', textAlign: 'right', padding: '0.95rem 1rem', fontSize: '0.82rem', borderBottom: idx === ab.history.length - 1 ? 'none' : '1px solid #e2e8f0', verticalAlign: 'middle'}}>
                                          <div style={{fontWeight: 700, fontSize: '0.9rem', color: priceColor}}>${h.total.toFixed(2)}</div>
                                          <div style={{fontSize: '0.68rem', color: '#64748b', marginTop: '2px'}}>(Total {totalItems} items)</div>
                                        </td>
                                      </tr>
                                    )
                                  })}
                                </tbody>
                              </table>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* CUSTOMER PROFILE VIEW */}
      {dashView === 'customers' && (
        <div className="p-4 md:p-8" style={{fontFamily: "'Inter', sans-serif", backgroundColor: '#f8fafc', color: '#0f172a', margin: '0', minHeight: 'calc(100vh - 80px)'}}>
          {/* Card */}
          <div style={{background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '12px', overflow: 'hidden', boxShadow: '0 1px 3px rgba(0,0,0,0.05)'}}>
            {/* Card Header */}
            <div style={{padding: '1.1rem 1.4rem', borderBottom: '1px solid #e2e8f0', display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
              <div>
                <div style={{fontSize: '1rem', fontWeight: 600, color: '#0f172a'}}>Customer Order History</div>
                <div style={{fontSize: '0.76rem', color: '#64748b', marginTop: '2px'}}>Overview of customer orders and spending</div>
              </div>
              <span style={{
                display: 'inline-flex', alignItems: 'center', gap: '0.18rem',
                padding: '0.3rem 0.7rem', fontSize: '0.7rem', fontWeight: 600,
                borderRadius: '20px', textTransform: 'uppercase', letterSpacing: '0.04em',
                background: '#d1fae5', color: '#16a34a'
              }}>
                <i className="ri-user-follow-line"></i> {customerProfiles.length} Active
              </span>
            </div>
            
            {/* Table */}
            <div style={{overflowX: 'auto'}}>
              <table style={{width: '100%', borderCollapse: 'collapse'}}>
                <thead>
                  <tr>
                    <th style={{width: '25%', textAlign: 'left', padding: '0.75rem 1.2rem', fontSize: '0.7rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#64748b', background: '#f8fafc', borderBottom: '1px solid #e2e8f0'}}>Customer</th>
                    <th style={{width: '25%', textAlign: 'left', padding: '0.75rem 1.2rem', fontSize: '0.7rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#64748b', background: '#f8fafc', borderBottom: '1px solid #e2e8f0'}}>Address</th>
                    <th style={{width: '25%', textAlign: 'left', padding: '0.75rem 1.2rem', fontSize: '0.7rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#64748b', background: '#f8fafc', borderBottom: '1px solid #e2e8f0'}}>Overview</th>
                    <th style={{width: '25%', textAlign: 'left', padding: '0.75rem 1.2rem', fontSize: '0.7rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em', color: '#64748b', background: '#f8fafc', borderBottom: '1px solid #e2e8f0'}}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {customerProfiles.map((cust) => (
                    <React.Fragment key={cust.id}>
                      {/* Main Row */}
                      <tr 
                        style={{cursor: 'pointer', transition: 'background 0.15s'}}
                        onClick={() => toggleCustomerExpand(cust.id)}
                        onMouseEnter={(e) => e.currentTarget.querySelectorAll('td').forEach(td => td.style.background = '#f8fafc')}
                        onMouseLeave={(e) => e.currentTarget.querySelectorAll('td').forEach(td => td.style.background = 'transparent')}>
                        <td style={{padding: '0.9rem 1.2rem', fontSize: '0.85rem', borderBottom: '1px solid #e2e8f0', verticalAlign: 'middle'}}>
                          <div style={{display: 'flex', alignItems: 'center', gap: '0.7rem'}}>
                            <div style={{
                              width: '34px', height: '34px', borderRadius: '50%', flexShrink: 0,
                              background: '#d1fae5', border: '1.5px solid #16a34a',
                              display: 'flex', alignItems: 'center', justifyContent: 'center',
                              fontWeight: 700, fontSize: '0.75rem', color: '#16a34a'
                            }}>{getInitials(cust.name)}</div>
                            <div>
                              <div style={{fontWeight: 600, fontSize: '0.875rem', color: '#0f172a'}}>{cust.name}</div>
                              <div style={{fontSize: '0.72rem', color: '#64748b', marginTop: '2px'}}>{cust.phone}</div>
                            </div>
                          </div>
                        </td>
                        <td style={{padding: '0.9rem 1.2rem', fontSize: '0.83rem', borderBottom: '1px solid #e2e8f0', verticalAlign: 'middle', color: '#475569'}}>{cust.address}</td>
                        <td style={{padding: '0.9rem 1.2rem', fontSize: '0.85rem', borderBottom: '1px solid #e2e8f0', verticalAlign: 'middle'}}>
                          <div style={{fontWeight: 500, fontSize: '0.83rem', color: '#0f172a'}}>Total {cust.totalOrders} Orders</div>
                          <div style={{fontSize: '0.71rem', color: '#64748b', marginTop: '2px'}}>Spent ${cust.totalSpent.toFixed(2)}</div>
                        </td>
                        <td style={{padding: '0.9rem 1.2rem', fontSize: '0.85rem', borderBottom: '1px solid #e2e8f0', verticalAlign: 'middle'}}>
                          <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingRight: '0.5rem'}}>
                            {/* Action Buttons */}
                            <div style={{display: 'flex', alignItems: 'center', gap: '0.6rem'}}>
                              <button onClick={(e) => { e.stopPropagation(); window.location.href = `tel:${cust.phone}`; }} 
                                style={{width: '28px', height: '28px', borderRadius: '6px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1rem', color: '#475569', background: '#f1f5f9', cursor: 'pointer', transition: 'all 0.2s', border: 'none'}}
                                onMouseEnter={(e) => { e.currentTarget.style.background = '#d1fae5'; e.currentTarget.style.color = '#16a34a'; }}
                                onMouseLeave={(e) => { e.currentTarget.style.background = '#f1f5f9'; e.currentTarget.style.color = '#475569'; }}>
                                <i className="ri-phone-line"></i>
                              </button>
                              <button onClick={(e) => { e.stopPropagation(); copyToClipboardLocal(cust.phone); }}
                                style={{width: '28px', height: '28px', borderRadius: '6px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1rem', color: '#475569', background: '#f1f5f9', cursor: 'pointer', transition: 'all 0.2s', border: 'none'}}
                                onMouseEnter={(e) => { e.currentTarget.style.background = '#e2e8f0'; e.currentTarget.style.color = '#0f172a'; }}
                                onMouseLeave={(e) => { e.currentTarget.style.background = '#f1f5f9'; e.currentTarget.style.color = '#475569'; }}>
                                <i className="ri-file-copy-line"></i>
                              </button>
                              <button onClick={(e) => { e.stopPropagation(); window.open(`https://wa.me/${cust.phone.replace('+', '')}`, '_blank'); }}
                                style={{width: '28px', height: '28px', borderRadius: '6px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1rem', color: '#475569', background: '#f1f5f9', cursor: 'pointer', transition: 'all 0.2s', border: 'none'}}
                                onMouseEnter={(e) => { e.currentTarget.style.background = '#dcfce7'; e.currentTarget.style.color = '#16a34a'; }}
                                onMouseLeave={(e) => { e.currentTarget.style.background = '#f1f5f9'; e.currentTarget.style.color = '#475569'; }}>
                                <i className="ri-whatsapp-line"></i>
                              </button>
                            </div>
                            <i className="ri-arrow-down-s-line" style={{
                              transition: 'transform 0.25s ease', fontSize: '1.2rem', color: '#64748b',
                              transform: expandedCustomer === cust.id ? 'rotate(180deg)' : 'rotate(0deg)'
                            }}></i>
                          </div>
                        </td>
                      </tr>
                      
                      {/* Expand Row */}
                      {expandedCustomer === cust.id && (
                        <tr>
                          <td colSpan={4} style={{padding: 0, background: '#ffffff', borderBottom: '1px solid #e2e8f0'}}>
                            <div style={{padding: '1.2rem 1.4rem'}}>
                              <table style={{width: '100%', borderCollapse: 'collapse'}}>
                                <tbody>
                                  {cust.orders.map((o, idx) => {
                                    const entries = buildEntries(o.products)
                                    const totalItems = entries.reduce((acc, e) => acc + e.qty, 0)
                                    
                                    return (
                                      <tr key={idx} style={{cursor: 'pointer'}} onMouseEnter={(e) => e.currentTarget.querySelectorAll('td').forEach(td => td.style.background = '#f8fafc')}>
                                        <td style={{width: '20%', whiteSpace: 'nowrap', padding: '0.95rem 1rem', fontSize: '0.82rem', borderBottom: idx === cust.orders.length - 1 ? 'none' : '1px solid #e2e8f0', verticalAlign: 'middle'}}>
                                          <div style={{fontSize: '0.82rem', fontWeight: 600, color: '#0f172a'}}>{o.date}</div>
                                          <div style={{fontSize: '0.7rem', color: '#64748b', marginTop: '3px'}}>
                                            Placed on <span style={{color: '#16a34a', fontWeight: 600}}>{o.visitCount}{getOrdinal(o.visitCount)}</span> visit
                                          </div>
                                        </td>
                                        <td style={{padding: '0.95rem 1rem', fontSize: '0.82rem', borderBottom: idx === cust.orders.length - 1 ? 'none' : '1px solid #e2e8f0', verticalAlign: 'middle'}}>
                                          <div style={{display: 'flex', flexWrap: 'wrap', alignItems: 'baseline', gap: 0, lineHeight: 1.6}}>
                                            {entries.map((e, i) => {
                                              const isLast = i === entries.length - 1
                                              const variantText = e.variant ? ` (${e.variant})` : ''
                                              return (
                                                <span key={i} style={{display: 'inline-flex', alignItems: 'baseline', gap: 0, fontSize: '0.81rem', color: '#475569'}}>
                                                  <span style={{color: '#0f172a', fontWeight: 500}}>{e.name}</span>
                                                  {e.variant && <span style={{color: '#64748b', fontSize: '0.75rem'}}>{variantText}</span>}
                                                  <span style={{color: '#16a34a', fontWeight: 700, fontSize: '0.75rem', marginLeft: '0.15rem'}}> ×{e.qty}</span>
                                                  {!isLast && <span style={{color: '#cbd5e1', margin: '0 0.6rem', fontSize: '0.8rem', opacity: 0.6}}>|</span>}
                                                </span>
                                              )
                                            })}
                                          </div>
                                        </td>
                                        <td style={{width: '15%', textAlign: 'right', padding: '0.95rem 1rem', fontSize: '0.82rem', borderBottom: idx === cust.orders.length - 1 ? 'none' : '1px solid #e2e8f0', verticalAlign: 'middle'}}>
                                          <div style={{fontWeight: 700, fontSize: '0.9rem', color: '#16a34a'}}>${o.total.toFixed(2)}</div>
                                          <div style={{fontSize: '0.68rem', color: '#64748b', marginTop: '2px'}}>(Total {totalItems} items)</div>
                                        </td>
                                      </tr>
                                    )
                                  })}
                                </tbody>
                              </table>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* INVENTORY MANAGEMENT VIEW */}
      {dashView === 'inventory' && (
        <div className="prod-mgmt-wrapper">
          <div style={{marginBottom: '20px', fontSize: '18px', fontWeight: 700, fontFamily: "'Plus Jakarta Sans'"}}>Inventory Management</div>
          
          {/* Stats Cards */}
          <div style={{display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '20px'}}>
            <div className="prod-order-card" style={{padding: '16px', display: 'flex', alignItems: 'center', gap: '12px'}}>
              <div style={{width: '40px', height: '40px', borderRadius: '8px', background: '#3b82f615', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                <i className="ri-archive-line" style={{color: '#3b82f6', fontSize: '20px'}}></i>
              </div>
              <div>
                <div style={{fontSize: '11px', color: '#8a96a8', textTransform: 'uppercase', letterSpacing: '0.5px'}}>Total Products</div>
                <div style={{fontSize: '20px', fontWeight: 700, color: '#1c2333'}}>{inventory.length}</div>
              </div>
            </div>
            <div className="prod-order-card" style={{padding: '16px', display: 'flex', alignItems: 'center', gap: '12px'}}>
              <div style={{width: '40px', height: '40px', borderRadius: '8px', background: '#8b5cf615', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                <i className="ri-stack-line" style={{color: '#8b5cf6', fontSize: '20px'}}></i>
              </div>
              <div>
                <div style={{fontSize: '11px', color: '#8a96a8', textTransform: 'uppercase', letterSpacing: '0.5px'}}>Total Varieties</div>
                <div style={{fontSize: '20px', fontWeight: 700, color: '#1c2333'}}>{inventory.reduce((acc, i) => acc + i.variants.length, 0)}</div>
              </div>
            </div>
            <div className="prod-order-card" style={{padding: '16px', display: 'flex', alignItems: 'center', gap: '12px'}}>
              <div style={{width: '40px', height: '40px', borderRadius: '8px', background: '#16a34a15', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                <i className="ri-checkbox-circle-line" style={{color: '#16a34a', fontSize: '20px'}}></i>
              </div>
              <div>
                <div style={{fontSize: '11px', color: '#8a96a8', textTransform: 'uppercase', letterSpacing: '0.5px'}}>Total Stock</div>
                <div style={{fontSize: '20px', fontWeight: 700, color: '#16a34a'}}>{inventory.reduce((acc, i) => acc + i.variants.reduce((vAcc, v) => vAcc + v.stock, 0), 0)}</div>
              </div>
            </div>
            <div className="prod-order-card" style={{padding: '16px', display: 'flex', alignItems: 'center', gap: '12px'}}>
              <div style={{width: '40px', height: '40px', borderRadius: '8px', background: '#ef444415', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                <i className="ri-alert-line" style={{color: '#ef4444', fontSize: '20px'}}></i>
              </div>
              <div>
                <div style={{fontSize: '11px', color: '#8a96a8', textTransform: 'uppercase', letterSpacing: '0.5px'}}>Low Stock</div>
                <div style={{fontSize: '20px', fontWeight: 700, color: '#ef4444'}}>{inventory.filter(i => i.variants.some(v => v.stock < 10)).length}</div>
              </div>
            </div>
          </div>

          {/* Inventory Table - Matching Product Section Design */}
          <div className="prod-container">
            <div className="inv-table-header">
              <div className="inv-grid-row">
                <div>Product Name</div>
                <div>Varieties</div>
                <div>Stock</div>
                <div>Last Edited</div>
                <div>Action</div>
              </div>
            </div>
            {inventory.map((item) => {
              const totalStock = item.variants.reduce((acc, v) => acc + v.stock, 0)
              const totalInitialStock = item.variants.reduce((acc, v) => acc + v.initialStock, 0)
              const isExpanded = expandedInventory === item.id
              
              return (
                <React.Fragment key={item.id}>
                  <div 
                    className="prod-order-card product-row"
                    style={{cursor: 'pointer'}}
                    onClick={() => setExpandedInventory(isExpanded ? null : item.id)}
                  >
                    <div className="inv-grid-row">
                      <div className="product-cell" style={{justifyContent: 'center'}}>
                        <img src={item.image} alt={item.name} className="inv-product-img" />
                        <div className="product-info">
                          <span className="product-name">{item.name}</span>
                          <span className="product-cat">{item.category}</span>
                        </div>
                      </div>
                      <div className="bracket-text text-blue">[{item.variants.length} varieties]</div>
                      <div className="bracket-text text-muted-val">[{totalStock} of {totalInitialStock}]</div>
                      <div className="text-muted-val">{item.lastEdited}</div>
                      <div className="inv-action-btns">
                        <button className="inv-btn-edit" onClick={(e) => { e.stopPropagation(); setEditingInventoryItem(item); }}>Edit</button>
                        <button className="inv-btn-delete" onClick={(e) => { e.stopPropagation(); setInventory(inventory.filter(i => i.id !== item.id)); }}>Delete</button>
                      </div>
                    </div>
                  </div>
                  
                  {/* Expanded Variants */}
                  {isExpanded && (
                    <div className="prod-order-card" style={{background: '#f8fafc', padding: '16px 20px 16px 70px'}}>
                      <div style={{fontSize: '11px', fontWeight: 600, color: '#8a96a8', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '12px'}}>Varieties Stock Details</div>
                      <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(120px, 1fr))', gap: '10px'}}>
                        {item.variants.map((variant, vIndex) => (
                          <div 
                            key={vIndex}
                            style={{padding: '10px 12px', background: 'white', borderRadius: '8px', border: '1px solid #e4e7ee'}}
                          >
                            <div style={{fontSize: '11px', color: '#64748b', marginBottom: '4px'}}>{variant.name}</div>
                            <div style={{fontSize: '13px', fontWeight: 600, color: '#1c2333'}}>
                              {variant.stock} <span style={{fontSize: '11px', fontWeight: 400, color: '#8a96a8'}}>of {variant.initialStock}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </React.Fragment>
              )
            })}
          </div>
          
          {/* Inventory Edit Modal */}
          {editingInventoryItem && (
            <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
              <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setEditingInventoryItem(null)}></div>
              <div className="relative bg-white w-full max-w-lg rounded-xl shadow-2xl p-6 max-h-[80vh] overflow-y-auto">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-[#1c2333]">Edit Stock - {editingInventoryItem.name}</h3>
                  <button onClick={() => setEditingInventoryItem(null)} className="text-[#8a96a8] hover:text-[#1c2333]">
                    <i className="ri-close-line text-xl"></i>
                  </button>
                </div>
                
                <div className="space-y-3">
                  {editingInventoryItem.variants.map((variant, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 bg-[#f8fafc] rounded-lg">
                      <div>
                        <div className="font-medium text-[#1c2333]">{variant.name}</div>
                        <div className="text-[11px] text-[#8a96a8]">Variety: {variant.initialStock}</div>
                      </div>
                      <input 
                        type="number"
                        value={variant.stock}
                        onChange={(e) => {
                          const newVariants = [...editingInventoryItem.variants];
                          newVariants[idx].stock = parseInt(e.target.value) || 0;
                          setEditingInventoryItem({...editingInventoryItem, variants: newVariants});
                        }}
                        className="w-20 px-3 py-2 border border-[#e4e7ee] rounded-lg text-center focus:outline-none focus:border-[#16a34a]"
                      />
                    </div>
                  ))}
                </div>
                
                <div className="flex gap-3 mt-6">
                  <button 
                    onClick={() => setEditingInventoryItem(null)}
                    className="flex-1 px-4 py-2 border border-[#e4e7ee] text-[#8a96a8] rounded-lg font-semibold hover:bg-[#f5f6f9] transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={() => {
                      setInventory(inventory.map(i => i.id === editingInventoryItem.id ? editingInventoryItem : i));
                      setEditingInventoryItem(null);
                      showToastMsg('Stock updated successfully!');
                    }}
                    className="flex-1 px-4 py-2 bg-[#16a34a] text-white rounded-lg font-semibold hover:bg-[#15803d] transition-colors"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* REVIEW MANAGEMENT VIEW */}
      {dashView === 'reviews' && (
        <div className="p-4 md:p-8" style={{fontFamily: "'Inter', sans-serif", backgroundColor: '#eef0f4', color: '#1c2333', margin: '0', minHeight: 'calc(100vh - 80px)'}}>
          {/* Header */}
          <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-2xl font-bold text-[#1c2333] tracking-tight">Review Management</h1>
              <p className="text-[#8a96a8] text-sm mt-1">Manage customer reviews and feedback</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="px-4 py-1.5 bg-[#16a34a]/10 text-[#16a34a] text-[13px] font-bold rounded-lg">
                {adminReviews.filter(r => r.rating >= 4).length} Positive
              </span>
              <span className="px-4 py-1.5 bg-[#ef4444]/10 text-[#ef4444] text-[13px] font-bold rounded-lg">
                {adminReviews.filter(r => r.rating < 3).length} Negative
              </span>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-white border border-[#e4e7ee] rounded-xl p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#f59e0b]/10 rounded-lg flex items-center justify-center">
                  <i className="ri-star-line text-[#f59e0b] text-xl"></i>
                </div>
                <div>
                  <div className="text-[11px] text-[#8a96a8] uppercase tracking-wider">Total Reviews</div>
                  <div className="text-xl font-bold text-[#1c2333]">{adminReviews.length}</div>
                </div>
              </div>
            </div>
            <div className="bg-white border border-[#e4e7ee] rounded-xl p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#16a34a]/10 rounded-lg flex items-center justify-center">
                  <i className="ri-star-fill text-[#16a34a] text-xl"></i>
                </div>
                <div>
                  <div className="text-[11px] text-[#8a96a8] uppercase tracking-wider">Avg Rating</div>
                  <div className="text-xl font-bold text-[#16a34a]">
                    {(adminReviews.reduce((acc, r) => acc + r.rating, 0) / adminReviews.length).toFixed(1)}
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-white border border-[#e4e7ee] rounded-xl p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#16a34a]/10 rounded-lg flex items-center justify-center">
                  <i className="ri-thumb-up-line text-[#16a34a] text-xl"></i>
                </div>
                <div>
                  <div className="text-[11px] text-[#8a96a8] uppercase tracking-wider">5 Star</div>
                  <div className="text-xl font-bold text-[#16a34a]">{adminReviews.filter(r => r.rating === 5).length}</div>
                </div>
              </div>
            </div>
            <div className="bg-white border border-[#e4e7ee] rounded-xl p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#ef4444]/10 rounded-lg flex items-center justify-center">
                  <i className="ri-thumb-down-line text-[#ef4444] text-xl"></i>
                </div>
                <div>
                  <div className="text-[11px] text-[#8a96a8] uppercase tracking-wider">1-2 Star</div>
                  <div className="text-xl font-bold text-[#ef4444]">{adminReviews.filter(r => r.rating <= 2).length}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Reviews Table */}
          <div className="bg-white border border-[#e4e7ee] rounded-xl shadow-sm overflow-hidden">
            <div className="p-4 border-b border-[#e4e7ee] flex items-center justify-between">
              <h3 className="text-base font-semibold text-[#1c2333]">Customer Reviews</h3>
              <div className="flex items-center gap-2">
                <select className="px-3 py-2 border border-[#e4e7ee] rounded-lg text-sm focus:outline-none focus:border-[#16a34a] text-[#8a96a8]">
                  <option>All Ratings</option>
                  <option>5 Stars</option>
                  <option>4 Stars</option>
                  <option>3 Stars</option>
                  <option>2 Stars</option>
                  <option>1 Star</option>
                </select>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-[13px]">
                <thead className="bg-[#f5f6f9] border-b border-[#e4e7ee]">
                  <tr>
                    <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase tracking-wider">Product</th>
                    <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase tracking-wider">Customer</th>
                    <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase tracking-wider">Review</th>
                    <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase tracking-wider">Date</th>
                    <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#e4e7ee]">
                  {adminReviews.map((review) => (
                    <tr key={review.id} className="hover:bg-[#f5f6f9]/50 transition-colors">
                      <td className="px-4 py-3">
                        <div>
                          <div className="font-semibold text-[#1c2333]">{review.product}</div>
                          <div className="text-[11px] text-[#8a96a8]">{review.productCategory}</div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div>
                          <div className="font-medium text-[#1c2333]">{review.customerName}</div>
                          <div className="flex items-center gap-0.5 mt-0.5">
                            {[1,2,3,4,5].map(star => (
                              <i 
                                key={star} 
                                className={`ri-star-${star <= review.rating ? 'fill' : 'line'} ${star <= review.rating ? 'text-[#f59e0b]' : 'text-[#e4e7ee]'}`}
                                style={{fontSize: '12px'}}
                              ></i>
                            ))}
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <p className="text-[#64748b] text-[12px] max-w-[280px] truncate">{review.text}</p>
                      </td>
                      <td className="px-4 py-3">
                        <div className="text-[#1c2333] text-[12px]">{review.date}</div>
                        <div className="text-[#8a96a8] text-[11px]">{review.time}</div>
                      </td>
                      <td className="px-4 py-3">
                        <button 
                          onClick={() => setAdminReviews(adminReviews.filter(r => r.id !== review.id))}
                          className="px-3 py-1.5 text-[11px] font-semibold text-[#ef4444] border border-[#ef4444] rounded-lg hover:bg-[#ef4444]/10 transition-colors"
                        >
                          <i className="ri-delete-bin-line mr-1"></i>Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SETTINGS VIEW */}
      {dashView === 'settings' && (
        <div className="p-4 md:p-8" style={{fontFamily: "'Inter', sans-serif", backgroundColor: '#f8fafc', color: '#0f172a', margin: '0', minHeight: 'calc(100vh - 80px)'}}>
          {/* Page content */}
          <div style={{padding: '2rem', maxWidth: '1200px', margin: '0 auto'}}>
            <div style={{display: 'grid', gridTemplateColumns: '1fr 1.5fr', gap: '2rem'}}>
              {/* Left Column: Branding & Links */}
              <div>
                {/* Branding Card */}
                <div style={{background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '12px', padding: '1.5rem', marginBottom: '1.5rem', boxShadow: '0 1px 3px rgba(0,0,0,0.05)'}}>
                  <h3 style={{fontSize: '1rem', fontWeight: 600, marginBottom: '1.25rem', color: '#16a34a', display: 'flex', alignItems: 'center', gap: '0.5rem'}}>
                    <i className="ri-medal-line"></i> Store Branding
                  </h3>
                  <div style={{marginBottom: '1rem'}}>
                    <label style={{display: 'block', fontSize: '0.8rem', color: '#64748b', marginBottom: '0.4rem', fontWeight: 500}}>Website Name</label>
                    <div style={{position: 'relative', display: 'flex', alignItems: 'center'}}>
                      <i className="ri-global-line" style={{position: 'absolute', left: '12px', color: '#64748b', fontSize: '1rem'}}></i>
                      <input type="text" placeholder="e.g. GroceryHub" value={settings.websiteName}
                        onChange={(e) => setSettings({...settings, websiteName: e.target.value})}
                        style={{width: '100%', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '0.6rem 0.8rem 0.6rem 2.5rem', color: '#0f172a', fontSize: '0.9rem', transition: 'border-color 0.2s', outline: 'none'}} 
                        onFocus={(e) => e.target.style.borderColor = '#16a34a'}
                        onBlur={(e) => e.target.style.borderColor = '#e2e8f0'} />
                    </div>
                  </div>
                  <div style={{marginBottom: '1rem'}}>
                    <label style={{display: 'block', fontSize: '0.8rem', color: '#64748b', marginBottom: '0.4rem', fontWeight: 500}}>Slogan</label>
                    <div style={{position: 'relative', display: 'flex', alignItems: 'center'}}>
                      <i className="ri-chat-quote-line" style={{position: 'absolute', left: '12px', color: '#64748b', fontSize: '1rem'}}></i>
                      <input type="text" placeholder="e.g. Freshness at your door" value={settings.slogan}
                        onChange={(e) => setSettings({...settings, slogan: e.target.value})}
                        style={{width: '100%', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '0.6rem 0.8rem 0.6rem 2.5rem', color: '#0f172a', fontSize: '0.9rem', transition: 'border-color 0.2s', outline: 'none'}}
                        onFocus={(e) => e.target.style.borderColor = '#16a34a'}
                        onBlur={(e) => e.target.style.borderColor = '#e2e8f0'} />
                    </div>
                  </div>
                  <div style={{marginBottom: '0'}}>
                    <label style={{display: 'block', fontSize: '0.8rem', color: '#64748b', marginBottom: '0.4rem', fontWeight: 500}}>Favicon URL</label>
                    <div style={{position: 'relative', display: 'flex', alignItems: 'center'}}>
                      <i className="ri-image-line" style={{position: 'absolute', left: '12px', color: '#64748b', fontSize: '1rem'}}></i>
                      <input type="text" placeholder="https://link-to-favicon.ico" value={settings.faviconUrl}
                        onChange={(e) => setSettings({...settings, faviconUrl: e.target.value})}
                        style={{width: '100%', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '0.6rem 0.8rem 0.6rem 2.5rem', color: '#0f172a', fontSize: '0.9rem', transition: 'border-color 0.2s', outline: 'none'}}
                        onFocus={(e) => e.target.style.borderColor = '#16a34a'}
                        onBlur={(e) => e.target.style.borderColor = '#e2e8f0'} />
                    </div>
                  </div>
                </div>

                {/* Delivery Card */}
                <div style={{background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '12px', padding: '1.5rem', marginBottom: '1.5rem', boxShadow: '0 1px 3px rgba(0,0,0,0.05)'}}>
                  <h3 style={{fontSize: '1rem', fontWeight: 600, marginBottom: '1.25rem', color: '#16a34a', display: 'flex', alignItems: 'center', gap: '0.5rem'}}>
                    <i className="ri-truck-line"></i> Delivery Settings
                  </h3>
                  <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem'}}>
                    <div>
                      <label style={{display: 'block', fontSize: '0.8rem', color: '#64748b', marginBottom: '0.4rem', fontWeight: 500}}>Inside Dhaka (TK)</label>
                      <div style={{position: 'relative', display: 'flex', alignItems: 'center'}}>
                        <i className="ri-map-pin-user-line" style={{position: 'absolute', left: '12px', color: '#64748b', fontSize: '1rem'}}></i>
                        <input type="number" value={settings.insideDhakaDelivery}
                          onChange={(e) => setSettings({...settings, insideDhakaDelivery: parseInt(e.target.value) || 0})}
                          style={{width: '100%', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '0.6rem 0.8rem 0.6rem 2.5rem', color: '#0f172a', fontSize: '0.9rem', transition: 'border-color 0.2s', outline: 'none'}}
                          onFocus={(e) => e.target.style.borderColor = '#16a34a'}
                          onBlur={(e) => e.target.style.borderColor = '#e2e8f0'} />
                      </div>
                    </div>
                    <div>
                      <label style={{display: 'block', fontSize: '0.8rem', color: '#64748b', marginBottom: '0.4rem', fontWeight: 500}}>Outside Dhaka (TK)</label>
                      <div style={{position: 'relative', display: 'flex', alignItems: 'center'}}>
                        <i className="ri-map-pin-2-line" style={{position: 'absolute', left: '12px', color: '#64748b', fontSize: '1rem'}}></i>
                        <input type="number" value={settings.outsideDhakaDelivery}
                          onChange={(e) => setSettings({...settings, outsideDhakaDelivery: parseInt(e.target.value) || 0})}
                          style={{width: '100%', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '0.6rem 0.8rem 0.6rem 2.5rem', color: '#0f172a', fontSize: '0.9rem', transition: 'border-color 0.2s', outline: 'none'}}
                          onFocus={(e) => e.target.style.borderColor = '#16a34a'}
                          onBlur={(e) => e.target.style.borderColor = '#e2e8f0'} />
                      </div>
                    </div>
                  </div>
                  <div style={{marginBottom: '0'}}>
                    <label style={{display: 'block', fontSize: '0.8rem', color: '#64748b', marginBottom: '0.4rem', fontWeight: 500}}>Free Delivery Minimum Amount (TK)</label>
                    <div style={{position: 'relative', display: 'flex', alignItems: 'center'}}>
                      <i className="ri-gift-line" style={{position: 'absolute', left: '12px', color: '#64748b', fontSize: '1rem'}}></i>
                      <input type="number" placeholder="e.g. 1000" value={settings.freeDeliveryMin}
                        onChange={(e) => setSettings({...settings, freeDeliveryMin: parseInt(e.target.value) || 0})}
                        style={{width: '100%', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '0.6rem 0.8rem 0.6rem 2.5rem', color: '#0f172a', fontSize: '0.9rem', transition: 'border-color 0.2s', outline: 'none'}}
                        onFocus={(e) => e.target.style.borderColor = '#16a34a'}
                        onBlur={(e) => e.target.style.borderColor = '#e2e8f0'} />
                    </div>
                  </div>
                </div>

                {/* Social Links */}
                <div style={{background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '12px', padding: '1.5rem', marginBottom: '0', boxShadow: '0 1px 3px rgba(0,0,0,0.05)'}}>
                  <h3 style={{fontSize: '1rem', fontWeight: 600, marginBottom: '1.25rem', color: '#16a34a', display: 'flex', alignItems: 'center', gap: '0.5rem'}}>
                    <i className="ri-links-line"></i> Social & Contact
                  </h3>
                  <div style={{marginBottom: '1rem'}}>
                    <label style={{display: 'block', fontSize: '0.8rem', color: '#64748b', marginBottom: '0.4rem', fontWeight: 500}}>WhatsApp Number</label>
                    <div style={{position: 'relative', display: 'flex', alignItems: 'center'}}>
                      <i className="ri-whatsapp-line" style={{position: 'absolute', left: '12px', color: '#64748b', fontSize: '1rem'}}></i>
                      <input type="text" placeholder="+8801xxxxxxxxx" value={settings.whatsappNumber}
                        onChange={(e) => setSettings({...settings, whatsappNumber: e.target.value})}
                        style={{width: '100%', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '0.6rem 0.8rem 0.6rem 2.5rem', color: '#0f172a', fontSize: '0.9rem', transition: 'border-color 0.2s', outline: 'none'}}
                        onFocus={(e) => e.target.style.borderColor = '#16a34a'}
                        onBlur={(e) => e.target.style.borderColor = '#e2e8f0'} />
                    </div>
                  </div>
                  <div style={{marginBottom: '1rem'}}>
                    <label style={{display: 'block', fontSize: '0.8rem', color: '#64748b', marginBottom: '0.4rem', fontWeight: 500}}>Phone Number</label>
                    <div style={{position: 'relative', display: 'flex', alignItems: 'center'}}>
                      <i className="ri-phone-line" style={{position: 'absolute', left: '12px', color: '#64748b', fontSize: '1rem'}}></i>
                      <input type="text" placeholder="+8801xxxxxxxxx" value={settings.phoneNumber}
                        onChange={(e) => setSettings({...settings, phoneNumber: e.target.value})}
                        style={{width: '100%', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '0.6rem 0.8rem 0.6rem 2.5rem', color: '#0f172a', fontSize: '0.9rem', transition: 'border-color 0.2s', outline: 'none'}}
                        onFocus={(e) => e.target.style.borderColor = '#16a34a'}
                        onBlur={(e) => e.target.style.borderColor = '#e2e8f0'} />
                    </div>
                  </div>
                  <div style={{marginBottom: '1rem'}}>
                    <label style={{display: 'block', fontSize: '0.8rem', color: '#64748b', marginBottom: '0.4rem', fontWeight: 500}}>Facebook Page URL</label>
                    <div style={{position: 'relative', display: 'flex', alignItems: 'center'}}>
                      <i className="ri-facebook-circle-line" style={{position: 'absolute', left: '12px', color: '#64748b', fontSize: '1rem'}}></i>
                      <input type="text" placeholder="https://facebook.com/yourpage" value={settings.facebookUrl}
                        onChange={(e) => setSettings({...settings, facebookUrl: e.target.value})}
                        style={{width: '100%', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '0.6rem 0.8rem 0.6rem 2.5rem', color: '#0f172a', fontSize: '0.9rem', transition: 'border-color 0.2s', outline: 'none'}}
                        onFocus={(e) => e.target.style.borderColor = '#16a34a'}
                        onBlur={(e) => e.target.style.borderColor = '#e2e8f0'} />
                    </div>
                  </div>
                  <div style={{marginBottom: '0'}}>
                    <label style={{display: 'block', fontSize: '0.8rem', color: '#64748b', marginBottom: '0.4rem', fontWeight: 500}}>Messenger Username</label>
                    <div style={{position: 'relative', display: 'flex', alignItems: 'center'}}>
                      <i className="ri-messenger-line" style={{position: 'absolute', left: '12px', color: '#64748b', fontSize: '1rem'}}></i>
                      <input type="text" placeholder="e.g. groceryhub.bd" value={settings.messengerUsername}
                        onChange={(e) => setSettings({...settings, messengerUsername: e.target.value})}
                        style={{width: '100%', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '0.6rem 0.8rem 0.6rem 2.5rem', color: '#0f172a', fontSize: '0.9rem', transition: 'border-color 0.2s', outline: 'none'}}
                        onFocus={(e) => e.target.style.borderColor = '#16a34a'}
                        onBlur={(e) => e.target.style.borderColor = '#e2e8f0'} />
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column: Content Pages */}
              <div>
                <div style={{background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '12px', padding: '1.5rem', marginBottom: '1.5rem', boxShadow: '0 1px 3px rgba(0,0,0,0.05)'}}>
                  <h3 style={{fontSize: '1rem', fontWeight: 600, marginBottom: '1.25rem', color: '#16a34a', display: 'flex', alignItems: 'center', gap: '0.5rem'}}>
                    <i className="ri-file-text-line"></i> Page Content (About & Policy)
                  </h3>

                  <div style={{marginBottom: '1rem'}}>
                    <label style={{display: 'block', fontSize: '0.8rem', color: '#64748b', marginBottom: '0.4rem', fontWeight: 500}}>About Us</label>
                    <textarea placeholder="Write about your company..." value={settings.aboutUs}
                      onChange={(e) => setSettings({...settings, aboutUs: e.target.value})}
                      style={{width: '100%', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '0.6rem 0.8rem', color: '#0f172a', fontSize: '0.9rem', transition: 'border-color 0.2s', outline: 'none', minHeight: '120px', resize: 'vertical'}}
                      onFocus={(e) => e.target.style.borderColor = '#16a34a'}
                      onBlur={(e) => e.target.style.borderColor = '#e2e8f0'}></textarea>
                  </div>

                  <div style={{marginBottom: '1rem'}}>
                    <label style={{display: 'block', fontSize: '0.8rem', color: '#64748b', marginBottom: '0.4rem', fontWeight: 500}}>Terms & Conditions</label>
                    <textarea placeholder="Company terms and rules..." value={settings.termsConditions}
                      onChange={(e) => setSettings({...settings, termsConditions: e.target.value})}
                      style={{width: '100%', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '0.6rem 0.8rem', color: '#0f172a', fontSize: '0.9rem', transition: 'border-color 0.2s', outline: 'none', minHeight: '120px', resize: 'vertical'}}
                      onFocus={(e) => e.target.style.borderColor = '#16a34a'}
                      onBlur={(e) => e.target.style.borderColor = '#e2e8f0'}></textarea>
                  </div>

                  <div style={{marginBottom: '1rem'}}>
                    <label style={{display: 'block', fontSize: '0.8rem', color: '#64748b', marginBottom: '0.4rem', fontWeight: 500}}>Refund Policy</label>
                    <textarea placeholder="Refund and return rules..." value={settings.refundPolicy}
                      onChange={(e) => setSettings({...settings, refundPolicy: e.target.value})}
                      style={{width: '100%', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '0.6rem 0.8rem', color: '#0f172a', fontSize: '0.9rem', transition: 'border-color 0.2s', outline: 'none', minHeight: '120px', resize: 'vertical'}}
                      onFocus={(e) => e.target.style.borderColor = '#16a34a'}
                      onBlur={(e) => e.target.style.borderColor = '#e2e8f0'}></textarea>
                  </div>

                  <div style={{marginBottom: '0'}}>
                    <label style={{display: 'block', fontSize: '0.8rem', color: '#64748b', marginBottom: '0.4rem', fontWeight: 500}}>Privacy Policy</label>
                    <textarea placeholder="How you handle customer data..." value={settings.privacyPolicy}
                      onChange={(e) => setSettings({...settings, privacyPolicy: e.target.value})}
                      style={{width: '100%', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '0.6rem 0.8rem', color: '#0f172a', fontSize: '0.9rem', transition: 'border-color 0.2s', outline: 'none', minHeight: '120px', resize: 'vertical'}}
                      onFocus={(e) => e.target.style.borderColor = '#16a34a'}
                      onBlur={(e) => e.target.style.borderColor = '#e2e8f0'}></textarea>
                  </div>
                </div>

                {/* Save Button */}
                <button onClick={handleSaveSettings}
                  style={{background: '#16a34a', color: '#ffffff', fontWeight: 700, padding: '0.8rem 2rem', borderRadius: '8px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContentContent: 'center', gap: '0.5rem', transition: 'transform 0.2s, opacity 0.2s', border: 'none', width: '100%', fontSize: '0.95rem'}}
                  onMouseEnter={(e) => { e.currentTarget.style.opacity = '0.9'; e.currentTarget.style.transform = 'translateY(-1px)'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.opacity = '1'; e.currentTarget.style.transform = 'translateY(0)'; }}>
                  <i className="ri-save-line"></i> Save Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CREDENTIALS VIEW */}
      {dashView === 'credentials' && (
        <div className="p-4 md:p-8" style={{fontFamily: "'Inter', sans-serif", backgroundColor: '#f8fafc', color: '#0f172a', margin: '0', minHeight: 'calc(100vh - 80px)'}}>
          {/* Main Content */}
          <div style={{width: '100%', maxWidth: '800px', margin: '0 auto', padding: '20px'}}>
            {/* Page Header */}
            <div style={{marginBottom: '32px'}}>
              <h1 style={{fontSize: '28px', fontWeight: 600, marginBottom: '8px'}}>Settings</h1>
              <p style={{color: '#64748b', fontSize: '15px'}}>Manage your account credentials and system integrations.</p>
            </div>

            {/* Account Security Card */}
            <div style={{backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '12px', padding: '32px', marginBottom: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)'}}>
              <div style={{marginBottom: '24px', paddingBottom: '16px', borderBottom: '1px solid #e2e8f0'}}>
                <h2 style={{fontSize: '18px', fontWeight: 600, color: '#0f172a'}}>Account Security</h2>
                <p style={{fontSize: '14px', color: '#64748b', marginTop: '4px'}}>Update your admin username and password here.</p>
              </div>

              <form onSubmit={handleSaveAccount}>
                <div style={{marginBottom: '20px'}}>
                  <label style={{display: 'block', fontSize: '14px', fontWeight: 500, color: '#0f172a', marginBottom: '8px'}}>Admin Username</label>
                  <input type="text" placeholder="e.g. admin_john" value={credentials.username} required
                    onChange={(e) => setCredentials({...credentials, username: e.target.value})}
                    style={{width: '100%', padding: '12px 16px', border: '1px solid #e2e8f0', borderRadius: '8px', fontSize: '14px', color: '#0f172a', backgroundColor: '#f8fafc', transition: 'all 0.2s', outline: 'none'}}
                    onFocus={(e) => { e.target.style.borderColor = '#16a34a'; e.target.style.boxShadow = '0 0 0 4px rgba(15, 118, 110, 0.15)'; }}
                    onBlur={(e) => { e.target.style.borderColor = '#e2e8f0'; e.target.style.boxShadow = 'none'; }} />
                </div>

                <div style={{marginBottom: '20px'}}>
                  <label style={{display: 'block', fontSize: '14px', fontWeight: 500, color: '#0f172a', marginBottom: '8px'}}>Current Password</label>
                  <input type="password" placeholder="Enter current password" value={credentials.currentPassword} required
                    onChange={(e) => setCredentials({...credentials, currentPassword: e.target.value})}
                    style={{width: '100%', padding: '12px 16px', border: '1px solid #e2e8f0', borderRadius: '8px', fontSize: '14px', color: '#0f172a', backgroundColor: '#f8fafc', transition: 'all 0.2s', outline: 'none'}}
                    onFocus={(e) => { e.target.style.borderColor = '#16a34a'; e.target.style.boxShadow = '0 0 0 4px rgba(15, 118, 110, 0.15)'; }}
                    onBlur={(e) => { e.target.style.borderColor = '#e2e8f0'; e.target.style.boxShadow = 'none'; }} />
                </div>

                <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '12px'}}>
                  <div>
                    <label style={{display: 'block', fontSize: '14px', fontWeight: 500, color: '#0f172a', marginBottom: '8px'}}>New Password</label>
                    <input type="password" placeholder="Enter new password" value={credentials.newPassword}
                      onChange={(e) => setCredentials({...credentials, newPassword: e.target.value})}
                      style={{width: '100%', padding: '12px 16px', border: '1px solid #e2e8f0', borderRadius: '8px', fontSize: '14px', color: '#0f172a', backgroundColor: '#f8fafc', transition: 'all 0.2s', outline: 'none'}}
                      onFocus={(e) => { e.target.style.borderColor = '#16a34a'; e.target.style.boxShadow = '0 0 0 4px rgba(15, 118, 110, 0.15)'; }}
                      onBlur={(e) => { e.target.style.borderColor = '#e2e8f0'; e.target.style.boxShadow = 'none'; }} />
                  </div>
                  <div>
                    <label style={{display: 'block', fontSize: '14px', fontWeight: 500, color: '#0f172a', marginBottom: '8px'}}>Confirm New Password</label>
                    <input type="password" placeholder="Confirm new password" value={credentials.confirmPassword}
                      onChange={(e) => setCredentials({...credentials, confirmPassword: e.target.value})}
                      style={{width: '100%', padding: '12px 16px', border: '1px solid #e2e8f0', borderRadius: '8px', fontSize: '14px', color: '#0f172a', backgroundColor: '#f8fafc', transition: 'all 0.2s', outline: 'none'}}
                      onFocus={(e) => { e.target.style.borderColor = '#16a34a'; e.target.style.boxShadow = '0 0 0 4px rgba(15, 118, 110, 0.15)'; }}
                      onBlur={(e) => { e.target.style.borderColor = '#e2e8f0'; e.target.style.boxShadow = 'none'; }} />
                  </div>
                </div>

                <div style={{display: 'flex', justifyContent: 'flex-end', marginTop: '12px'}}>
                  <button type="submit"
                    style={{backgroundColor: '#16a34a', color: 'white', border: 'none', padding: '12px 24px', borderRadius: '8px', fontSize: '14px', fontWeight: 500, cursor: 'pointer', transition: 'background-color 0.2s', display: 'inline-flex', alignItems: 'center', justifyContent: 'center'}}
                    onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#16a34a'}
                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#16a34a'}>
                    Save Account Changes
                  </button>
                </div>
              </form>
            </div>

            {/* Courier API Integration Card */}
            <div style={{backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '12px', padding: '32px', marginBottom: '0', boxShadow: '0 1px 3px rgba(0,0,0,0.05)'}}>
              <div style={{marginBottom: '24px', paddingBottom: '16px', borderBottom: '1px solid #e2e8f0'}}>
                <h2 style={{fontSize: '18px', fontWeight: 600, color: '#0f172a'}}>Courier Service API</h2>
                <p style={{fontSize: '14px', color: '#64748b', marginTop: '4px'}}>Configure your logistics provider keys and webhook URL.</p>
              </div>

              <form onSubmit={handleSaveApi}>
                <div style={{marginBottom: '20px'}}>
                  <label style={{display: 'block', fontSize: '14px', fontWeight: 500, color: '#0f172a', marginBottom: '8px'}}>API Key</label>
                  <input type="text" placeholder="pk_live_xxxxxxxxxxxxxxxxxxxx" value={credentials.apiKey} required
                    onChange={(e) => setCredentials({...credentials, apiKey: e.target.value})}
                    style={{width: '100%', padding: '12px 16px', border: '1px solid #e2e8f0', borderRadius: '8px', fontSize: '14px', color: '#0f172a', backgroundColor: '#f8fafc', transition: 'all 0.2s', outline: 'none'}}
                    onFocus={(e) => { e.target.style.borderColor = '#16a34a'; e.target.style.boxShadow = '0 0 0 4px rgba(15, 118, 110, 0.15)'; }}
                    onBlur={(e) => { e.target.style.borderColor = '#e2e8f0'; e.target.style.boxShadow = 'none'; }} />
                </div>

                <div style={{marginBottom: '20px'}}>
                  <label style={{display: 'block', fontSize: '14px', fontWeight: 500, color: '#0f172a', marginBottom: '8px'}}>Secret Key</label>
                  <input type="password" placeholder="sk_live_xxxxxxxxxxxxxxxxxxxx" value={credentials.secretKey} required
                    onChange={(e) => setCredentials({...credentials, secretKey: e.target.value})}
                    style={{width: '100%', padding: '12px 16px', border: '1px solid #e2e8f0', borderRadius: '8px', fontSize: '14px', color: '#0f172a', backgroundColor: '#f8fafc', transition: 'all 0.2s', outline: 'none'}}
                    onFocus={(e) => { e.target.style.borderColor = '#16a34a'; e.target.style.boxShadow = '0 0 0 4px rgba(15, 118, 110, 0.15)'; }}
                    onBlur={(e) => { e.target.style.borderColor = '#e2e8f0'; e.target.style.boxShadow = 'none'; }} />
                </div>

                <div style={{marginBottom: '20px'}}>
                  <label style={{display: 'block', fontSize: '14px', fontWeight: 500, color: '#0f172a', marginBottom: '8px'}}>Webhook Endpoint URL</label>
                  <input type="url" placeholder="https://yourdomain.com/api/webhooks/courier" value={credentials.webhookUrl} required
                    onChange={(e) => setCredentials({...credentials, webhookUrl: e.target.value})}
                    style={{width: '100%', padding: '12px 16px', border: '1px solid #e2e8f0', borderRadius: '8px', fontSize: '14px', color: '#0f172a', backgroundColor: '#f8fafc', transition: 'all 0.2s', outline: 'none'}}
                    onFocus={(e) => { e.target.style.borderColor = '#16a34a'; e.target.style.boxShadow = '0 0 0 4px rgba(15, 118, 110, 0.15)'; }}
                    onBlur={(e) => { e.target.style.borderColor = '#e2e8f0'; e.target.style.boxShadow = 'none'; }} />
                </div>

                <div style={{display: 'flex', justifyContent: 'flex-end', marginTop: '12px'}}>
                  <button type="submit"
                    style={{backgroundColor: '#16a34a', color: 'white', border: 'none', padding: '12px 24px', borderRadius: '8px', fontSize: '14px', fontWeight: 500, cursor: 'pointer', transition: 'background-color 0.2s', display: 'inline-flex', alignItems: 'center', justifyContent: 'center'}}
                    onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#16a34a'}
                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#16a34a'}>
                    Save API Configuration
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {isModalOpen && (
        <div className="admin-modal" onClick={(e) => { if((e.target as HTMLElement).classList.contains('admin-modal')) setIsModalOpen(false); }}>
          <div className="admin-modal-content">
            <h3 style={{marginBottom: '24px', fontWeight: 600}}>Add Inventory</h3>
            <form onSubmit={handleAddProductInventory}>
              <div className="input-group"><label>Product Name</label><input type="text" required placeholder="e.g. Greek Yogurt" value={newProduct.name} onChange={(e) => setNewProduct({...newProduct, name: e.target.value})} /></div>
              <div className="input-group"><label>Stock Level</label><input type="number" required placeholder="50" value={newProduct.stock} onChange={(e) => setNewProduct({...newProduct, stock: e.target.value})} /></div>
              <div style={{display: 'flex', gap: '12px', marginTop: '24px'}}>
                <button type="button" className="btn-admin-minimal" onClick={() => setIsModalOpen(false)} style={{flex: 1}}>Cancel</button>
                <button type="submit" className="btn-admin-minimal btn-admin-primary" style={{flex: 1}}>Save</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className={`cat-toast ${showToast ? 'show' : ''}`}>
        <i className="ri-check-double-line" style={{color: '#16a34a', fontSize: '16px'}}></i>
        <span>{toastMsg}</span>
      </div>
      </main>
    </div>
  )
}

// --- MAIN APP ENTRY ---
export default function Home() {
  const [view, setView] = useState('shop')
  const [cartItems, setCartItems] = useState<CartItem[]>([]) 
  const [orders, setOrders] = useState<{ id: string }[]>([]) 

  const addToCart = (item: CartItem) => setCartItems([...cartItems, item])

  const handleConfirmOrder = () => {
    setOrders([{ id: 'ORD-45921' }])
    setCartItems([])
    setView('orders')
    window.scrollTo(0,0)
  }

  return (
    <div className="flex flex-col min-h-screen relative">
      <Header view={view} setView={setView} cartCount={cartItems.length} />
      <div className="flex-grow w-full">
        {view === 'shop' && <Shop setView={setView} addToCart={addToCart} />}
        {view === 'product' && <ProductDetail setView={setView} addToCart={addToCart} />}
        {view === 'cart' && <Cart setView={setView} cartItems={cartItems} setCartItems={setCartItems} />}
        {view === 'checkout' && <Checkout setView={setView} onConfirm={handleConfirmOrder} />}
        {view === 'orders' && <Orders orders={orders} setView={setView} />}
        {view === 'admin' && <AdminDashboard setView={setView} />}
      </div>
      <BottomNav view={view} setView={setView} />
    </div>
  )
}
